'use strict';

const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const config = require('../config');
const logger = require('../utils/logger');

/** Ensure all storage directories exist */
function ensureDirs() {
  for (const dir of Object.values(config.paths)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

/** Generate a UUID-based safe filename preserving original extension */
function storagePath(fileId, extension) {
  const safeName = `${fileId}${extension}`;
  return path.join(config.paths.uploads, safeName);
}

function processedPath(fileId) {
  return path.join(config.paths.processed, `${fileId}.json`);
}

function chunksPath(fileId) {
  return path.join(config.paths.chunks, `${fileId}.json`);
}

function indexPath(fileId) {
  return path.join(config.paths.index, `${fileId}.json`);
}

/** Remove all artifacts for a file */
function cleanupFile(fileId) {
  const dirs = [config.paths.uploads, config.paths.processed, config.paths.chunks, config.paths.index];
  for (const dir of dirs) {
    try {
      const files = fs.readdirSync(dir);
      for (const f of files) {
        if (f.startsWith(fileId)) {
          fs.unlinkSync(path.join(dir, f));
          logger.info({ fileId, file: f }, 'Cleaned up file artifact');
        }
      }
    } catch (err) {
      logger.warn({ err, fileId, dir }, 'Cleanup warning');
    }
  }
}

/** Save processed analysis result to disk (caching) */
function saveProcessedResult(fileId, data) {
  const filePath = processedPath(fileId);
  fs.writeFileSync(filePath, JSON.stringify(data), 'utf-8');
}

function loadProcessedResult(fileId) {
  const filePath = processedPath(fileId);
  if (!fs.existsSync(filePath)) return null;
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return null;
  }
}

/** Save chunks to disk */
function saveChunks(fileId, chunks) {
  const filePath = chunksPath(fileId);
  fs.writeFileSync(filePath, JSON.stringify(chunks), 'utf-8');
}

function loadChunks(fileId) {
  const filePath = chunksPath(fileId);
  if (!fs.existsSync(filePath)) return null;
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return null;
  }
}

/** Save retrieval index to disk */
function saveIndex(fileId, indexData) {
  const filePath = indexPath(fileId);
  fs.writeFileSync(filePath, JSON.stringify(indexData), 'utf-8');
}

function loadIndex(fileId) {
  const filePath = indexPath(fileId);
  if (!fs.existsSync(filePath)) return null;
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return null;
  }
}

module.exports = {
  ensureDirs,
  storagePath,
  processedPath,
  chunksPath,
  indexPath,
  cleanupFile,
  saveProcessedResult,
  loadProcessedResult,
  saveChunks,
  loadChunks,
  saveIndex,
  loadIndex,
};
