'use strict';

const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');
const { ERROR_CODES, AppError } = require('../utils/errorCodes');
const { validateUpload, validateMagicOnDisk } = require('../validators/fileValidator');
const { sanitizeFilename, getExtension, detectCategory } = require('../utils/fileSecurity');
const { FileRegistry, FILE_STATUSES } = require('../models/fileState');
const { storagePath, saveProcessedResult, loadProcessedResult, saveChunks, loadChunks, cleanupFile } = require('../storage/manager');
const { invokePython } = require('../workers/pythonWorker');
const { generateInsights } = require('../ai/openrouter.service');
const config = require('../config');

const registry = new FileRegistry();

/**
 * Handle complete file upload pipeline:
 * 1. Validate uploaded file
 * 2. Save to disk with UUID name
 * 3. Validate magic bytes
 * 4. Register in memory
 * 5. Return metadata
 */
function uploadFile(file) {
  const validation = validateUpload(file);
  const fileId = uuidv4();
  const safeName = sanitizeFilename(file.originalname);

  // Save file with UUID name
  const diskPath = storagePath(fileId, validation.extension);
  fs.copyFileSync(file.path, diskPath);

  // Validate magic bytes on disk
  validateMagicOnDisk(diskPath, validation.extension);

  // Register file
  const entry = registry.register(fileId, {
    fileName: safeName,
    extension: validation.extension,
    mimeType: file.mimetype,
    category: validation.category,
    diskPath,
  });

  logger.info({ fileId, extension: validation.extension, category: validation.category }, 'File uploaded');

  return {
    fileId,
    fileName: safeName,
    originalName: safeName,
    fileSize: file.size,
    extension: validation.extension,
    mimeType: validation.mimeType,
    category: validation.category,
    status: FILE_STATUSES.UPLOADED,
    uploadedAt: new Date().toISOString(),
  };
}

/**
 * Full analysis pipeline:
 * 1. Parse the file (Python)
 * 2. Analyze tabular or document (Python)
 * 3. Chunk documents for RAG
 * 4. Generate AI insights
 * 5. Cache results
 */
async function analyzeFile(fileId) {
  const entry = registry.get(fileId);
  if (!entry) throw new AppError(ERROR_CODES.FILE_NOT_FOUND);

  // Check cache
  const cached = loadProcessedResult(fileId);
  if (cached) {
    logger.info({ fileId }, 'Returning cached analysis result');
    return cached;
  }

  // Acquire lock
  if (!registry.acquireLock(fileId)) {
    throw new AppError(ERROR_CODES.PROCESSING_IN_PROGRESS);
  }

  try {
    // Step 1: Parse
    registry.updateStatus(fileId, FILE_STATUSES.PARSING);
    const parseResult = await invokePython('parse', {
      fileId,
      filePath: entry.diskPath,
      format: entry.extension,
      category: entry.category,
    });
    const parsedData = parseResult.data;

    let analysisResult;

    if (parsedData.fileType === 'TABULAR') {
      // Step 2: Full tabular analysis
      registry.updateStatus(fileId, FILE_STATUSES.ANALYZING);
      const analyzeResult = await invokePython('analyze', parsedData);
      analysisResult = analyzeResult.data;

      // Step 3: Generate AI insights
      registry.updateStatus(fileId, FILE_STATUSES.INDEXING);
      const contextStr = _buildInsightContext(analysisResult);
      try {
        const insights = await generateInsights(contextStr);
        analysisResult.insights = insights;
      } catch (err) {
        logger.warn({ err, fileId }, 'AI insight generation failed, continuing without insights');
        analysisResult.insights = null;
        analysisResult.insightsError = 'AI service unavailable';
      }

    } else if (parsedData.fileType === 'DOCUMENT') {
      // Step 2: Document analysis + chunking
      registry.updateStatus(fileId, FILE_STATUSES.INDEXING);
      const docResult = await invokePython('document_analyze', parsedData);
      analysisResult = docResult.data;

      // Step 3: Chunk document for RAG
      const chunkResult = await invokePython('chunk_document', {
        document: parsedData.document,
      });
      const chunks = chunkResult.data?.chunks || [];
      saveChunks(fileId, chunks);
      analysisResult.chunkCount = chunks.length;

      // Step 4: Generate AI insights for document
      try {
        const docContext = _buildDocumentInsightContext(analysisResult);
        const insights = await generateInsights(docContext);
        analysisResult.insights = insights;
      } catch (err) {
        logger.warn({ err, fileId }, 'AI insight generation failed for document');
        analysisResult.insights = null;
        analysisResult.insightsError = 'AI service unavailable';
      }
    } else {
      throw new AppError(ERROR_CODES.INVALID_DATASET, { detail: `Unknown file type: ${parsedData.fileType}` });
    }

    // Cache result
    saveProcessedResult(fileId, analysisResult);
    registry.updateAnalysis(fileId, analysisResult);

    logger.info({ fileId, fileType: analysisResult.fileType }, 'Analysis complete');
    return analysisResult;

  } catch (err) {
    registry.markFailed(fileId, err.message);
    if (!(err instanceof AppError)) {
      throw new AppError(ERROR_CODES.PROCESSING_FAILED, { detail: err.message });
    }
    throw err;
  } finally {
    registry.releaseLock(fileId);
  }
}

function getStatus(fileId) {
  const entry = registry.get(fileId);
  if (!entry) throw new AppError(ERROR_CODES.FILE_NOT_FOUND);
  return {
    fileId: entry.fileId,
    status: entry.status,
    category: entry.category,
    error: entry.error || null,
  };
}

function getAnalysis(fileId) {
  const cached = loadProcessedResult(fileId);
  if (!cached) throw new AppError(ERROR_CODES.FILE_NOT_FOUND, { detail: 'Analysis not found. Run analysis first.' });
  return cached;
}

function _buildInsightContext(analysis) {
  const parts = [];
  parts.push(`Dataset: ${analysis.rowCount} rows x ${analysis.colCount} columns`);
  parts.push(`Columns: ${analysis.columns.join(', ')}`);
  parts.push(`Column Types: ${JSON.stringify(analysis.typeMap || {})}`);

  const kpis = (analysis.kpis || []).slice(0, 15);
  parts.push('Key Metrics:');
  for (const kpi of kpis) {
    parts.push(`  ${kpi.label}: ${kpi.value}${kpi.subtitle ? ` (${kpi.subtitle})` : ''}`);
  }

  const corrs = (analysis.correlations || []).slice(0, 10);
  if (corrs.length > 0) {
    parts.push('Top Correlations:');
    for (const c of corrs) {
      parts.push(`  ${c.columnA} & ${c.columnB}: ${c.correlation} (${c.strength} ${c.direction})`);
    }
  }

  const cleaning = analysis.cleaning || {};
  if (cleaning.rowsRemoved > 0) {
    parts.push(`Cleaning: ${cleaning.rowsRemoved} rows removed, ${cleaning.originalRows} -> ${cleaning.finalRows}`);
  }

  return parts.join('\n');
}

function _buildDocumentInsightContext(analysis) {
  const doc = analysis.document || {};
  const parts = [];
  parts.push(`Document Type: ${doc.documentType}`);
  parts.push(`Total Pages: ${doc.totalPages}`);
  parts.push(`Sections: ${(doc.sections || []).length}`);
  parts.push(`Tables: ${(doc.tables || []).length}`);

  const meta = doc.metadata || {};
  if (Object.keys(meta).length > 0) {
    parts.push('Metadata: ' + JSON.stringify(meta));
  }

  if (doc.fullText) {
    parts.push('Content excerpt:');
    parts.push(doc.fullText.substring(0, 5000));
  }

  return parts.join('\n');
}

module.exports = {
  uploadFile,
  analyzeFile,
  getStatus,
  getAnalysis,
  registry,
};
