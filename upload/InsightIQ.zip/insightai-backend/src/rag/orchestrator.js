'use strict';

const logger = require('../utils/logger');
const { invokePython } = require('../workers/pythonWorker');
const { answerQuestion } = require('../ai/openrouter.service');
const { ERROR_CODES, AppError } = require('../utils/errorCodes');
const storage = require('../storage/manager');
const config = require('../config');

/**
 * RAG Orchestrator: handles the full RAG pipeline for chat questions.
 * 1. Route the question
 * 2. Retrieve relevant chunks (for documents)
 * 3. Build context
 * 4. Call LLM
 * 5. Return grounded answer with sources
 */
async function handleChat(fileId, question) {
  // Load cached analysis result
  const analysis = storage.loadProcessedResult(fileId);
  if (!analysis) {
    throw new AppError(ERROR_CODES.FILE_NOT_FOUND, {
      detail: 'File analysis not found. Please upload and analyze the file first.',
    });
  }

  const fileType = analysis.fileType || analysis.category || 'UNKNOWN';
  let chunks = storage.loadChunks(fileId);

  // If no chunks cached, this might be tabular data — no chunks needed
  let retrievedChunks = [];

  // Step 1: For documents, retrieve relevant chunks
  if (fileType === 'DOCUMENT' && chunks && chunks.length > 0) {
    try {
      const retrieveResult = await invokePython('retrieve', {
        question,
        chunks,
        topK: config.rag.topK,
      });
      retrievedChunks = retrieveResult.data?.retrievedChunks || [];
    } catch (err) {
      logger.warn({ err, fileId }, 'Chunk retrieval failed, continuing without retrieved chunks');
    }
  }

  // Step 2: Build context
  let contextStr;
  try {
    const contextResult = await invokePython('build_context', {
      question,
      fileType,
      analysis,
      chunks: chunks || [],
      retrievedChunks,
    });
    contextStr = contextResult.data?.context || '';
  } catch (err) {
    logger.warn({ err, fileId }, 'Context building failed, using fallback context');
    contextStr = _buildFallbackContext(analysis);
  }

  // Step 3: Call LLM
  const answer = await answerQuestion(question, contextStr);

  // Step 4: Build source citations
  const sources = retrievedChunks.map((chunk) => ({
    type: 'document',
    page: chunk.page || null,
    section: chunk.section || null,
    chunkId: chunk.chunkId || null,
    score: chunk.score || null,
  }));

  // For tabular data, add calculation-based sources
  if (fileType === 'TABULAR') {
    const qLower = question.toLowerCase();
    for (const col of (analysis.columns || [])) {
      if (qLower.includes(col.toLowerCase()) && analysis.statistics?.[col]) {
        sources.push({
          type: 'calculation',
          column: col,
          calculation: 'Descriptive statistics',
        });
      }
    }
  }

  return {
    answer,
    grounded: true,
    sources: sources.length > 0 ? sources : undefined,
    questionType: contextStr ? 'resolved' : 'general',
  };
}

function _buildFallbackContext(analysis) {
  const parts = [];
  if (analysis.fileType === 'TABULAR') {
    parts.push(`Dataset: ${analysis.rowCount} rows, ${analysis.colCount} columns`);
    parts.push(`Columns: ${(analysis.columns || []).join(', ')}`);
    const kpis = (analysis.kpis || []).slice(0, 10);
    for (const kpi of kpis) {
      parts.push(`${kpi.label}: ${kpi.value}${kpi.subtitle ? ` (${kpi.subtitle})` : ''}`);
    }
  } else if (analysis.fileType === 'DOCUMENT') {
    const doc = analysis.document || {};
    const text = doc.fullText || '';
    parts.push(text.substring(0, 4000));
  }
  return parts.join('\n');
}

module.exports = { handleChat };
