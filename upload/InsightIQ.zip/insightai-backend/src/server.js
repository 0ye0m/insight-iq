'use strict';

const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const logger = require('./utils/logger');
const { FileRegistry } = require('./models/fileState');
const { cleanupFile } = require('./storage/manager');
const app = require('./app');

/**
 * Verify Python engine is available at startup.
 * Logs a warning (not fatal) so the server still boots — uploads work,
 * but analysis will fail with a clear message.
 */
function checkPythonEngine() {
  const pyPath = config.analytics.pythonPath;
  const scriptPath = config.analytics.scriptPath;

  let ver;
  try {
    ver = execFileSync(pyPath, ['--version'], {
      stdio: 'pipe',
      timeout: 5000,
      windowsHide: true,
    }).toString().trim();
  } catch (err) {
    logger.warn(
      { pythonPath: pyPath, scriptPath, error: err.message },
      'Python analytics engine NOT available — file upload works but analysis will fail. ' +
      'Install Python 3.9+ and run: pip install -r requirements.txt'
    );
    return;
  }

  if (!fs.existsSync(scriptPath)) {
    logger.warn({ pythonPath: pyPath, scriptPath }, 'Python found but analytics script missing');
    return;
  }

  logger.info({ pythonPath: pyPath, version: ver }, 'Python analytics engine ready');
}

checkPythonEngine();

const server = app.listen(config.port, () => {
  logger.info({ port: config.port, env: config.env, python: config.analytics.pythonPath }, 'InsightAI backend started');
});

// Graceful shutdown
function shutdown(signal) {
  logger.info({ signal }, 'Shutting down...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Periodic cleanup of expired files
const cleanupInterval = setInterval(() => {
  const { registry } = require('./services/fileProcessing.service');
  const retentionMs = config.retention.hours * 60 * 60 * 1000;
  const expired = registry.cleanup(retentionMs);
  if (expired > 0) {
    logger.info({ expired }, 'Cleaned up expired files');
  }
}, 60 * 60 * 1000); // Every hour

// Don't keep the process alive just for cleanup
if (cleanupInterval.unref) cleanupInterval.unref();

module.exports = server;
