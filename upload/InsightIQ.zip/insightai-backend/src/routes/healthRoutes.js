'use strict';

const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const express = require('express');
const router = express.Router();

/** Check if Python engine is actually functional */
function checkPythonStatus() {
  const pyPath = require('../config').analytics.pythonPath;
  const scriptPath = require('../config').analytics.scriptPath;

  try {
    execFileSync(pyPath, ['--version'], { stdio: 'pipe', timeout: 5000, windowsHide: true });
  } catch {
    return { status: 'unavailable', pythonPath: pyPath };
  }

  if (!fs.existsSync(scriptPath)) {
    return { status: 'missing_script', pythonPath: pyPath };
  }

  return { status: 'available', pythonPath: pyPath };
}

/** GET /api/health */
router.get('/', (_req, res) => {
  const config = require('../config');
  const openRouterConfigured = !!config.openrouter.apiKey;
  const pythonStatus = checkPythonStatus();

  res.json({
    success: true,
    data: {
      status: pythonStatus.status === 'available' ? 'healthy' : 'degraded',
      service: 'insightai-backend',
      analyticsEngine: pythonStatus.status,
      analyticsPythonPath: pythonStatus.pythonPath,
      ocr: config.ocr.enabled ? 'available' : 'disabled',
      openRouter: openRouterConfigured ? 'configured' : 'not configured',
      environment: config.env,
    },
  });
});

module.exports = router;
