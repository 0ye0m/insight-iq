'use strict';

const express = require('express');
const {
  upload,
  uploadHandler,
  analyzeHandler,
  statusHandler,
  getAnalysisHandler,
  chatHandler,
  exportCleanedHandler,
  exportReportHandler,
} = require('../controllers/fileController');

const router = express.Router();

// Upload
router.post('/upload', upload.single('file'), uploadHandler);

// Analyze
router.post('/:fileId/analyze', analyzeHandler);

// Status
router.get('/:fileId/status', statusHandler);

// Get analysis result
router.get('/:fileId/analysis', getAnalysisHandler);

// Chat
router.post('/:fileId/chat', chatHandler);

// Export
router.get('/:fileId/export/cleaned', exportCleanedHandler);
router.get('/:fileId/export/report', exportReportHandler);

module.exports = router;
