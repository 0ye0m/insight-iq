'use strict';

const express = require('express');
const {
  helmet, cors, apiLimiter, uploadLimiter,
  requestLogger, errorHandler, notFoundHandler,
} = require('./middleware');
const config = require('./config');
const { ensureDirs } = require('./storage/manager');
const fileRoutes = require('./routes/fileRoutes');
const healthRoutes = require('./routes/healthRoutes');

// Ensure storage directories exist
ensureDirs();

const app = express();

// Security middleware
app.use(helmet);
app.use(cors);

// Body parsing (limited)
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));

// Request logging
app.use(requestLogger);

// Rate limiting
app.use('/api/', apiLimiter);

// Routes
app.use('/api/health', healthRoutes);
app.use('/api/files', uploadLimiter, fileRoutes);

// Error handling
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
