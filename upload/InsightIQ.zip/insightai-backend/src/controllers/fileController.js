'use strict';

const multer = require('multer');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');
const { ERROR_CODES, AppError } = require('../utils/errorCodes');
const fileService = require('../services/fileProcessing.service');
const { generateReport } = require('../exporters/reportGenerator');
const { handleChat } = require('../rag/orchestrator');
const { storagePath } = require('../storage/manager');
const config = require('../config');
const { FILE_STATUSES } = require('../models/fileState');

// Multer config: store to temp, we handle it from there
const multerDest = path.join(os.tmpdir(), 'insightai-uploads');
fs.mkdirSync(multerDest, { recursive: true });

const upload = multer({
  dest: multerDest,
  limits: {
    fileSize: config.upload.maxFileSizeBytes,
  },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowed = ['.csv', '.tsv', '.txt', '.json', '.jsonl', '.ndjson', '.xlsx', '.xls', '.ods', '.parquet', '.pdf', '.docx', '.doc', '.pptx', '.ppt', '.odt', '.rtf', '.md', '.markdown', '.html', '.htm', '.xml', '.zip'];
    if (allowed.includes(ext)) {
      cb(null, true);
    } else {
      cb(new AppError(ERROR_CODES.UNSUPPORTED_FORMAT));
    }
  },
});

/** POST /api/files/upload */
async function uploadHandler(req, res, next) {
  try {
    if (!req.file) {
      throw new AppError(ERROR_CODES.INVALID_FILE, { detail: 'No file in request.' });
    }
    const result = fileService.uploadFile(req.file);
    // Clean up multer temp file
    try { fs.unlinkSync(req.file.path); } catch {}
    res.json({ success: true, data: result, message: 'File uploaded successfully' });
  } catch (err) { next(err); }
}

/** POST /api/files/:fileId/analyze */
async function analyzeHandler(req, res, next) {
  try {
    const { fileId } = req.params;
    const result = await fileService.analyzeFile(fileId);
    // Strip insightsError from response in non-error cases
    const response = { ...result };
    if (response.insightsError) {
      response.aiAvailable = false;
      delete response.insightsError;
    } else {
      response.aiAvailable = true;
    }
    res.json({ success: true, data: response });
  } catch (err) { next(err); }
}

/** GET /api/files/:fileId/status */
async function statusHandler(req, res, next) {
  try {
    const { fileId } = req.params;
    const status = fileService.getStatus(fileId);
    res.json({ success: true, data: status });
  } catch (err) { next(err); }
}

/** GET /api/files/:fileId/analysis */
async function getAnalysisHandler(req, res, next) {
  try {
    const { fileId } = req.params;
    const analysis = fileService.getAnalysis(fileId);
    res.json({ success: true, data: analysis });
  } catch (err) { next(err); }
}

/** POST /api/files/:fileId/chat */
async function chatHandler(req, res, next) {
  try {
    const { fileId } = req.params;
    const { question } = req.body;
    if (!question || typeof question !== 'string' || !question.trim()) {
      throw new AppError(ERROR_CODES.INVALID_FILE, { detail: 'Question is required.' });
    }
    const result = await handleChat(fileId, question.trim());
    res.json({ success: true, data: result });
  } catch (err) { next(err); }
}

/** GET /api/files/:fileId/export/cleaned */
async function exportCleanedHandler(req, res, next) {
  try {
    const { fileId } = req.params;
    const format = (req.query.format || 'csv').toLowerCase();
    const analysis = fileService.getAnalysis(fileId);

    if (analysis.fileType !== 'TABULAR') {
      throw new AppError(ERROR_CODES.EXPORT_FAILED, { detail: 'Cleaned data export is only available for tabular files.' });
    }

    if (format === 'csv') {
      const { invokePython } = require('../workers/pythonWorker');
      const entry = fileService.registry.get(fileId);
      const csvResult = await invokePython('export_cleaned_csv', {
        filePath: entry?.diskPath,
        format: analysis.format,
        category: analysis.category,
      });
      const csvData = csvResult.data?.csv || '';
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="cleaned_${fileId}.csv"`);
      res.send(csvData);
    } else {
      throw new AppError(ERROR_CODES.EXPORT_FAILED, { detail: `Unsupported export format: ${format}. Use 'csv'.` });
    }
  } catch (err) { next(err); }
}

/** GET /api/files/:fileId/export/report */
async function exportReportHandler(req, res, next) {
  try {
    const { fileId } = req.params;
    const analysis = fileService.getAnalysis(fileId);
    const insights = analysis.insights || null;

    const buffer = await generateReport(analysis, insights);

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="insightai_report_${fileId}.xlsx"`);
    res.send(buffer);
  } catch (err) { next(err); }
}

module.exports = {
  upload,
  uploadHandler,
  analyzeHandler,
  statusHandler,
  getAnalysisHandler,
  chatHandler,
  exportCleanedHandler,
  exportReportHandler,
};
