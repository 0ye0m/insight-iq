'use strict';

const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const logger = require('../utils/logger');
const { ERROR_CODES, AppError } = require('../utils/errorCodes');

/**
 * Sanitize error objects before sending to client.
 * Never expose stack traces, env vars, or internal paths in production.
 */
function sanitizeError(err) {
  if (err instanceof AppError) {
    return {
      code: err.code,
      message: err.message,
      details: err.details,
    };
  }
  if (err.type === 'entity.too.large') {
    return ERROR_CODES.FILE_TOO_LARGE;
  }
  // In production, hide internal details
  if (process.env.NODE_ENV === 'production') {
    return ERROR_CODES.INTERNAL_ERROR;
  }
  return {
    code: 'INTERNAL_ERROR',
    message: err.message || 'An internal error occurred.',
    details: process.env.NODE_ENV !== 'production' ? { stack: err.stack } : undefined,
  };
}

function errorHandler(err, req, res, _next) {
  const errorInfo = sanitizeError(err);
  const httpStatus = err.httpStatus || err.statusCode || 500;

  logger.error({
    err,
    code: errorInfo.code,
    path: req.path,
    method: req.method,
  }, 'Request error');

  res.status(httpStatus).json({
    success: false,
    error: errorInfo,
  });
}

function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    error: {
      code: 'NOT_FOUND',
      message: `Route ${req.method} ${req.path} not found.`,
    },
  });
}

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    res.status(429).json({
      success: false,
      error: ERROR_CODES.RATE_LIMITED,
    });
  },
});

const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    res.status(429).json({
      success: false,
      error: ERROR_CODES.RATE_LIMITED,
    });
  },
});

function requestLogger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    logger.info({
      method: req.method,
      path: req.path,
      status: res.statusCode,
      durationMs: duration,
    }, 'Request completed');
  });
  next();
}

module.exports = {
  helmet: helmet(),
  cors: cors({
    origin: '*',
    methods: ['GET', 'POST', 'DELETE'],
    allowedHeaders: ['Content-Type'],
  }),
  apiLimiter,
  uploadLimiter,
  requestLogger,
  errorHandler,
  notFoundHandler,
};
