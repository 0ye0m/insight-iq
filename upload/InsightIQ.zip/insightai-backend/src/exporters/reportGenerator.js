'use strict';

const ExcelJS = require('exceljs');
const { ERROR_CODES, AppError } = require('../utils/errorCodes');
const logger = require('../utils/logger');

/**
 * Generate a multi-sheet ExcelJS analysis report.
 * For tabular data: File Summary, Cleaning Report, Column Profile, Descriptive Statistics, KPIs, Correlations, Chart Data, AI Insights.
 * For documents: Document Summary, Metadata, Extracted Sections, Extracted Tables, AI Insights.
 */
async function generateReport(analysis, insights) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'InsightAI';
  workbook.created = new Date();

  const fileType = analysis.fileType;

  if (fileType === 'TABULAR') {
    _addSummarySheet(workbook, analysis);
    _addCleaningSheet(workbook, analysis);
    _addProfileSheet(workbook, analysis);
    _addStatisticsSheet(workbook, analysis);
    _addKpiSheet(workbook, analysis);
    _addCorrelationSheet(workbook, analysis);
    _addChartSheet(workbook, analysis);
  } else if (fileType === 'DOCUMENT') {
    _addDocSummarySheet(workbook, analysis);
    _addDocMetadataSheet(workbook, analysis);
    _addDocSectionsSheet(workbook, analysis);
    _addDocTablesSheet(workbook, analysis);
  }

  // AI Insights sheet (common)
  if (insights) {
    _addInsightsSheet(workbook, insights);
  }

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

function _addSummarySheet(wb, analysis) {
  const ws = wb.addWorksheet('File Summary', { properties: { tabColor: { argb: '4472C4' } } });
  ws.columns = [{ header: 'Property', key: 'prop', width: 30 }, { header: 'Value', key: 'val', width: 50 }];
  const rows = [
    ['File ID', analysis.fileId],
    ['Format', analysis.format],
    ['Category', analysis.category],
    ['Total Rows', analysis.rowCount],
    ['Total Columns', analysis.colCount],
    ['Columns', (analysis.columns || []).join(', ')],
  ];
  const pi = analysis.parseInfo || {};
  if (pi.encoding) rows.push(['Encoding', pi.encoding]);
  if (pi.delimiter) rows.push(['Delimiter', pi.delimiter]);
  if (pi.selectedSheet) rows.push(['Sheet', pi.selectedSheet]);
  rows.forEach(([p, v]) => ws.addRow({ prop: p, val: String(v ?? '') }));
}

function _addCleaningSheet(wb, analysis) {
  const ws = wb.addWorksheet('Cleaning Report', { properties: { tabColor: { argb: 'ED7D31' } } });
  ws.columns = [{ header: 'Property', key: 'prop', width: 30 }, { header: 'Value', key: 'val', width: 50 }];
  const cl = analysis.cleaning || {};
  ws.addRow({ prop: 'Original Rows', val: cl.originalRows });
  ws.addRow({ prop: 'Final Rows', val: cl.finalRows });
  ws.addRow({ prop: 'Rows Removed', val: cl.rowsRemoved });
  ws.addRow({ prop: 'Steps Performed', val: (cl.steps || []).length });
  for (const step of (cl.steps || [])) {
    ws.addRow({});
    ws.addRow({ prop: `Step: ${step.action}` });
    if (step.columnsHandled) {
      for (const ch of step.columnsHandled) {
        ws.addRow({ prop: `  ${ch.column}`, val: `${ch.missingCount} missing (${ch.percentage}%) - Strategy: ${ch.strategy}` });
      }
    }
    if (step.detected !== undefined) {
      ws.addRow({ prop: '  Duplicates detected', val: step.detected });
      ws.addRow({ prop: '  Duplicates removed', val: step.removed });
    }
  }
}

function _addProfileSheet(wb, analysis) {
  const ws = wb.addWorksheet('Column Profile', { properties: { tabColor: { argb: 'A5A5A5' } } });
  ws.columns = [
    { header: 'Column', key: 'col', width: 25 },
    { header: 'Type', key: 'type', width: 15 },
    { header: 'Total Values', key: 'total', width: 15 },
    { header: 'Missing', key: 'missing', width: 12 },
    { header: 'Missing %', key: 'missingPct', width: 12 },
    { header: 'Unique', key: 'unique', width: 12 },
  ];
  const profile = analysis.profile || {};
  for (const [col, info] of Object.entries(profile)) {
    ws.addRow({
      col: info.column || col,
      type: info.dtype,
      total: info.totalValues,
      missing: info.missingCount,
      missingPct: info.missingPercentage,
      unique: info.uniqueCount,
    });
  }
}

function _addStatisticsSheet(wb, analysis) {
  const ws = wb.addWorksheet('Descriptive Statistics', { properties: { tabColor: { argb: 'FFC000' } } });
  ws.columns = [
    { header: 'Column', key: 'col', width: 20 },
    { header: 'Count', key: 'count', width: 12 },
    { header: 'Mean', key: 'mean', width: 14 },
    { header: 'Median', key: 'median', width: 14 },
    { header: 'Std Dev', key: 'std', width: 14 },
    { header: 'Min', key: 'min', width: 14 },
    { header: 'Max', key: 'max', width: 14 },
    { header: 'Q1', key: 'q1', width: 14 },
    { header: 'Q3', key: 'q3', width: 14 },
  ];
  const stats = analysis.statistics || {};
  for (const [col, s] of Object.entries(stats)) {
    if (s.error) continue;
    ws.addRow({
      col, count: s.count, mean: s.mean, median: s.median,
      std: s.std, min: s.min, max: s.max, q1: s.q1, q3: s.q3,
    });
  }
}

function _addKpiSheet(wb, analysis) {
  const ws = wb.addWorksheet('KPIs', { properties: { tabColor: { argb: '70AD47' } } });
  ws.columns = [
    { header: 'KPI', key: 'label', width: 30 },
    { header: 'Value', key: 'value', width: 20 },
    { header: 'Type', key: 'type', width: 12 },
    { header: 'Importance', key: 'importance', width: 12 },
    { header: 'Notes', key: 'subtitle', width: 30 },
  ];
  for (const kpi of (analysis.kpis || [])) {
    ws.addRow({
      label: kpi.label, value: String(kpi.value),
      type: kpi.type, importance: kpi.importance, subtitle: kpi.subtitle || '',
    });
  }
}

function _addCorrelationSheet(wb, analysis) {
  const ws = wb.addWorksheet('Correlations', { properties: { tabColor: { argb: '5B9BD5' } } });
  ws.columns = [
    { header: 'Column A', key: 'a', width: 20 },
    { header: 'Column B', key: 'b', width: 20 },
    { header: 'Correlation', key: 'corr', width: 14 },
    { header: 'Direction', key: 'dir', width: 12 },
    { header: 'Strength', key: 'strength', width: 12 },
  ];
  for (const c of (analysis.correlations || [])) {
    ws.addRow({ a: c.columnA, b: c.columnB, corr: c.correlation, dir: c.direction, strength: c.strength });
  }
}

function _addChartSheet(wb, analysis) {
  const ws = wb.addWorksheet('Chart Data', { properties: { tabColor: { argb: 'BF8F00' } } });
  let row = 1;
  for (const chart of (analysis.visualizations || [])) {
    ws.getCell(row, 1).value = `Chart: ${chart.title}`;
    ws.getCell(row, 1).font = { bold: true };
    row++;
    ws.getCell(row, 1).value = `Type: ${chart.type}`;
    row++;
    const labels = chart.data?.labels || [];
    const datasets = chart.data?.datasets || [];
    // Header row
    ws.getCell(row, 1).value = 'Label';
    for (let di = 0; di < datasets.length; di++) {
      ws.getCell(row, di + 2).value = datasets[di].label || `Dataset ${di + 1}`;
    }
    row++;
    for (let li = 0; li < labels.length; li++) {
      ws.getCell(row, 1).value = labels[li];
      for (let di = 0; di < datasets.length; di++) {
        ws.getCell(row, di + 2).value = datasets[di].data?.[li] ?? '';
      }
      row++;
    }
    row += 2;
  }
}

function _addDocSummarySheet(wb, analysis) {
  const ws = wb.addWorksheet('Document Summary', { properties: { tabColor: { argb: '4472C4' } } });
  ws.columns = [{ header: 'Property', key: 'prop', width: 25 }, { header: 'Value', key: 'val', width: 60 }];
  const doc = analysis.document || {};
  ws.addRow({ prop: 'File ID', val: analysis.fileId });
  ws.addRow({ prop: 'Format', val: analysis.format });
  ws.addRow({ prop: 'Document Type', val: doc.documentType });
  ws.addRow({ prop: 'Total Pages', val: doc.totalPages });
  ws.addRow({ prop: 'Sections', val: (doc.sections || []).length });
  ws.addRow({ prop: 'Tables', val: (doc.tables || []).length });
  if (doc.ocrRequired) ws.addRow({ prop: 'OCR Required', val: 'Yes' });
  if (doc.ocrUsed) ws.addRow({ prop: 'OCR Used', val: 'Yes' });
}

function _addDocMetadataSheet(wb, analysis) {
  const ws = wb.addWorksheet('Metadata', { properties: { tabColor: { argb: 'A5A5A5' } } });
  ws.columns = [{ header: 'Key', key: 'k', width: 20 }, { header: 'Value', key: 'v', width: 50 }];
  const meta = analysis.document?.metadata || {};
  for (const [k, v] of Object.entries(meta)) {
    if (v) ws.addRow({ k, v: String(v) });
  }
}

function _addDocSectionsSheet(wb, analysis) {
  const ws = wb.addWorksheet('Extracted Sections', { properties: { tabColor: { argb: 'ED7D31' } } });
  ws.columns = [{ header: 'Section', key: 'heading', width: 30 }, { header: 'Content', key: 'content', width: 80 }];
  for (const sec of (analysis.document?.sections || [])) {
    ws.addRow({ heading: sec.heading, content: (sec.content || '').substring(0, 32000) });
  }
}

function _addDocTablesSheet(wb, analysis) {
  const ws = wb.addWorksheet('Extracted Tables', { properties: { tabColor: { argb: '5B9BD5' } } });
  let tables = analysis.document?.tables || [];
  for (const t of tables) {
    ws.addRow({});
    ws.getCell(ws.rowCount, 1).value = `Table ${t.tableIndex || '?'} (Page ${t.page || 'N/A'})`;
    ws.getCell(ws.rowCount, 1).font = { bold: true };
    ws.addRow(t.headers || []);
    for (const row of (t.rows || [])) {
      ws.addRow(row);
    }
  }
}

function _addInsightsSheet(wb, insights) {
  const ws = wb.addWorksheet('AI Insights', { properties: { tabColor: { argb: '7030A0' } } });
  ws.columns = [
    { header: 'Type', key: 'type', width: 15 },
    { header: 'Title / Description', key: 'title', width: 50 },
    { header: 'Evidence', key: 'evidence', width: 50 },
    { header: 'Importance', key: 'importance', width: 12 },
  ];
  ws.addRow({ type: 'Summary', title: insights.summary });
  for (const ins of (insights.keyInsights || [])) {
    ws.addRow({
      type: 'Insight', title: `${ins.title}: ${ins.description}`,
      evidence: JSON.stringify(ins.evidence || []), importance: ins.importance,
    });
  }
  for (const t of (insights.trends || [])) {
    ws.addRow({ type: 'Trend', title: t.description, evidence: JSON.stringify(t.evidence || []) });
  }
  for (const a of (insights.anomalies || [])) {
    ws.addRow({ type: 'Anomaly', title: a.description, evidence: JSON.stringify(a.evidence || []) });
  }
  for (const r of (insights.recommendations || [])) {
    ws.addRow({ type: 'Recommendation', title: r.description, evidence: JSON.stringify(r.evidence || []) });
  }
}

module.exports = { generateReport };
