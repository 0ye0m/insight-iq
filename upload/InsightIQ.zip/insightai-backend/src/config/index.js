'use strict';

const path = require('path');
const { execFileSync } = require('child_process');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });

/**
 * Detect Python executable.
 * On Windows, 'python3' doesn't exist — must try 'python' first.
 * Respects PYTHON_PATH env var override.
 */
function detectPythonPath() {
  if (process.env.PYTHON_PATH) return process.env.PYTHON_PATH;

  const candidates = process.platform === 'win32'
    ? ['python', 'python3', 'py']
    : ['python3', 'python'];

  for (const cmd of candidates) {
    try {
      const version = execFileSync(cmd, ['--version'], {
        stdio: 'pipe',
        timeout: 5000,
        windowsHide: true,
      }).toString().trim();
      if (version.startsWith('Python ')) {
        return cmd;
      }
    } catch {
      // not found, try next
    }
  }
  return 'python'; // last resort
}

const detectedPython = detectPythonPath();

const config = {
  env: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 5000,

  upload: {
    maxFileSizeBytes: (parseInt(process.env.MAX_FILE_SIZE_MB, 10) || 50) * 1024 * 1024,
    maxRows: parseInt(process.env.MAX_ROWS, 10) || 100000,
    maxColumns: parseInt(process.env.MAX_COLUMNS, 10) || 500,
    maxPages: parseInt(process.env.MAX_PAGES, 10) || 200,
    maxExtractedTextChars: parseInt(process.env.MAX_EXTRACTED_TEXT_CHARS, 10) || 500000,
    maxZipFiles: parseInt(process.env.MAX_ZIP_FILES, 10) || 20,
    maxZipTotalSizeBytes: (parseInt(process.env.MAX_ZIP_TOTAL_SIZE_MB, 10) || 100) * 1024 * 1024,
  },

  retention: {
    hours: parseInt(process.env.FILE_RETENTION_HOURS, 10) || 24,
  },

  analytics: {
    pythonPath: detectedPython,
    scriptPath: path.resolve(__dirname, '../../analytics/main.py'),
    timeoutMs: parseInt(process.env.ANALYTICS_TIMEOUT_MS, 10) || 120000,
  },

  openrouter: {
    apiKey: process.env.OPENROUTER_API_KEY || '',
    model: process.env.OPENROUTER_MODEL || 'google/gemini-2.0-flash-001',
    baseUrl: process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1',
    timeoutMs: parseInt(process.env.OPENROUTER_TIMEOUT_MS, 10) || 30000,
    maxRetries: parseInt(process.env.OPENROUTER_MAX_RETRIES, 10) || 3,
  },

  rag: {
    chunkSize: parseInt(process.env.CHUNK_SIZE, 10) || 1000,
    chunkOverlap: parseInt(process.env.CHUNK_OVERLAP, 10) || 200,
    maxChunks: parseInt(process.env.MAX_CHUNKS, 10) || 500,
    topK: parseInt(process.env.RAG_TOP_K, 10) || 5,
  },

  ocr: {
    enabled: process.env.OCR_ENABLED === 'true',
  },

  logLevel: process.env.LOG_LEVEL || 'info',

  paths: {
    uploads: path.resolve(__dirname, '../../uploads'),
    processed: path.resolve(__dirname, '../../data/processed'),
    chunks: path.resolve(__dirname, '../../data/chunks'),
    index: path.resolve(__dirname, '../../data/index'),
  },
};

module.exports = config;
