#!/usr/bin/env python3
"""
INSIGHTAI Analytics Engine - Main Entry Point

Receives JSON commands via stdin, executes the requested operation,
and writes JSON results to stdout.

This script is never executed as a public HTTP service.
It is only invoked by the Node.js backend via controlled subprocess.
"""

import sys
import json
import os
import traceback

# Ensure analytics package is importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from loaders.csv_loader import load_csv_tsv_txt
from loaders.json_loader import load_json
from loaders.excel_loader import load_excel
from loaders.parquet_loader import load_parquet
from documents.pdf_parser import parse_pdf
from documents.docx_parser import parse_docx
from documents.pptx_parser import parse_pptx
from documents.odt_parser import parse_odt
from documents.rtf_parser import parse_rtf
from documents.html_parser import parse_html
from documents.xml_parser import parse_xml
from documents.markdown_parser import parse_markdown
from cleaning.cleaner import clean_dataframe
from cleaning.type_detection import detect_column_types
from analysis.profiler import profile_dataset
from analysis.statistics import compute_statistics
from analysis.kpi import generate_kpis
from analysis.correlation import compute_correlations
from analysis.visualization import generate_visualizations
from rag.chunker import chunk_document
from rag.retriever import retrieve_chunks
from rag.context_builder import build_tabular_context, build_document_context, build_mixed_context
from rag.question_router import route_question


def get_config():
    return {
        'max_rows': int(os.environ.get('MAX_ROWS', '100000')),
        'max_columns': int(os.environ.get('MAX_COLUMNS', '500')),
        'max_pages': int(os.environ.get('MAX_PAGES', '200')),
        'max_extracted_text_chars': int(os.environ.get('MAX_EXTRACTED_TEXT_CHARS', '500000')),
        'chunk_size': int(os.environ.get('CHUNK_SIZE', '1000')),
        'chunk_overlap': int(os.environ.get('CHUNK_OVERLAP', '200')),
        'max_chunks': int(os.environ.get('MAX_CHUNKS', '500')),
        'rag_top_k': int(os.environ.get('RAG_TOP_K', '5')),
        'ocr_enabled': os.environ.get('OCR_ENABLED', 'false').lower() == 'true',
    }


def handle_parse(cmd_data, cfg):
    """Parse an uploaded file into a normalized representation."""
    file_path = cmd_data['filePath']
    file_format = cmd_data['format']
    category = cmd_data.get('category', 'UNKNOWN')

    result = {
        'version': '1.0',
        'fileId': cmd_data.get('fileId', ''),
        'format': file_format,
        'category': category,
    }

    if category in ('TABULAR', 'UNKNOWN'):
        df, parse_info = _parse_tabular(file_path, file_format, cfg)
        if df is not None:
            result['fileType'] = 'TABULAR'
            result['parseInfo'] = parse_info
            result['schema'] = _build_schema(df)
            # Cache cleaned df for later steps
            result['_df_json'] = df.to_json(orient='split', date_format='iso')
            result['_row_count'] = len(df)
            result['_col_count'] = len(df.columns)
            return result

    if category == 'DOCUMENT' or file_format in ('pdf', 'docx', 'pptx', 'odt', 'rtf', 'html', 'htm', 'xml', 'md', 'markdown'):
        doc_result = _parse_document(file_path, file_format, cfg)
        if doc_result:
            result['fileType'] = 'DOCUMENT'
            if result.get('category') == 'UNKNOWN':
                result['category'] = 'DOCUMENT'
            result['document'] = doc_result
            return result

    # If unknown format, try tabular first then document
    df, parse_info = _parse_tabular(file_path, file_format, cfg)
    if df is not None:
        result['fileType'] = 'TABULAR'
        result['category'] = 'TABULAR'
        result['parseInfo'] = parse_info
        result['schema'] = _build_schema(df)
        result['_df_json'] = df.to_json(orient='split', date_format='iso')
        result['_row_count'] = len(df)
        result['_col_count'] = len(df.columns)
        return result

    raise ValueError(f'Cannot parse file format: {file_format}')


def _parse_tabular(file_path, fmt, cfg):
    """Try to parse as tabular data. Returns (df, info) or (None, None)."""
    try:
        if fmt in ('.csv', '.tsv', '.txt'):
            return load_csv_tsv_txt(file_path, cfg)
        elif fmt in ('.json', '.jsonl', '.ndjson'):
            return load_json(file_path, cfg)
        elif fmt in ('.xlsx', '.xls', '.ods'):
            return load_excel(file_path, cfg)
        elif fmt == '.parquet':
            return load_parquet(file_path, cfg)
    except Exception as e:
        return None, {'error': str(e)}
    return None, {'error': 'No tabular parser for format'}


def _parse_document(file_path, fmt, cfg):
    """Parse as a document. Returns document dict or None."""
    try:
        if fmt == '.pdf':
            return parse_pdf(file_path, cfg)
        elif fmt == '.docx':
            return parse_docx(file_path, cfg)
        elif fmt == '.pptx':
            return parse_pptx(file_path, cfg)
        elif fmt == '.odt':
            return parse_odt(file_path, cfg)
        elif fmt in ('.rtf',):
            return parse_rtf(file_path, cfg)
        elif fmt in ('.html', '.htm'):
            return parse_html(file_path, cfg)
        elif fmt == '.xml':
            return parse_xml(file_path, cfg)
        elif fmt in ('.md', '.markdown'):
            return parse_markdown(file_path, cfg)
    except Exception as e:
        return {'error': str(e)}
    return None


def _build_schema(df):
    """Build a schema object from a DataFrame."""
    schema = {}
    for col in df.columns:
        dtype_str = str(df[col].dtype)
        schema[col] = {
            'dtype': dtype_str,
            'nullable': df[col].isna().any(),
            'uniqueCount': int(df[col].nunique()),
            'sampleValues': df[col].dropna().head(5).tolist(),
        }
    return schema


def _restore_df(result):
    """Restore a DataFrame from cached JSON."""
    import pandas as pd, io
    if '_df_json' not in result:
        return None
    return pd.read_json(io.StringIO(result['_df_json']), orient='split')


def handle_analyze(cmd_data, cfg):
    """Run full analysis pipeline on a parsed tabular file."""
    result = cmd_data  # This is the parse result from handle_parse
    df = _restore_df(result)
    if df is None:
        raise ValueError('No tabular data available for analysis')

    # Clean
    df_clean, cleaning_log = clean_dataframe(df, cfg)

    # Profile
    column_profiles = profile_dataset(df_clean, cfg)

    # Type detection
    type_map = detect_column_types(df_clean)

    # Statistics
    statistics = compute_statistics(df_clean, type_map, cfg)

    # KPIs
    kpis = generate_kpis(df_clean, type_map, statistics)

    # Correlations
    correlations = compute_correlations(df_clean, type_map)

    # Visualizations
    visualizations = generate_visualizations(df_clean, type_map, statistics, cfg)

    # Build final result (strip internal _df_json to avoid huge response)
    final = {
        'version': '1.0',
        'fileId': result.get('fileId', ''),
        'fileType': 'TABULAR',
        'format': result.get('format', ''),
        'category': 'TABULAR',
        'schema': result.get('schema', {}),
        'parseInfo': result.get('parseInfo', {}),
        'cleaning': cleaning_log,
        'profile': column_profiles,
        'typeMap': type_map,
        'statistics': statistics,
        'kpis': kpis,
        'correlations': correlations,
        'visualizations': visualizations,
        'rowCount': len(df_clean),
        'colCount': len(df_clean.columns),
        'columns': list(df_clean.columns),
    }
    return final


def handle_document_analyze(cmd_data, cfg):
    """Run analysis on a parsed document."""
    result = cmd_data
    doc = result.get('document', {})
    if not doc:
        raise ValueError('No document data available for analysis')

    # Chunk the document for RAG
    chunks = chunk_document(doc, cfg)

    final = {
        'version': '1.0',
        'fileId': result.get('fileId', ''),
        'fileType': 'DOCUMENT',
        'format': result.get('format', ''),
        'category': 'DOCUMENT',
        'document': doc,
        'chunkCount': len(chunks),
    }
    return final


def handle_retrieve(cmd_data, cfg):
    """Retrieve relevant chunks for a question."""
    question = cmd_data['question']
    chunks = cmd_data.get('chunks', [])
    top_k = cmd_data.get('topK', cfg['rag_top_k'])

    results = retrieve_chunks(question, chunks, top_k)
    return {'retrievedChunks': results}


def handle_build_context(cmd_data, cfg):
    """Build LLM context for a question."""
    question = cmd_data['question']
    file_type = cmd_data['fileType']
    analysis = cmd_data.get('analysis', {})
    chunks = cmd_data.get('chunks', [])
    retrieved = cmd_data.get('retrievedChunks', [])

    # Route the question
    question_type = route_question(question, file_type, analysis)

    if file_type == 'TABULAR':
        context = build_tabular_context(question, question_type, analysis, retrieved, cfg)
    elif file_type == 'DOCUMENT':
        context = build_document_context(question, question_type, analysis, retrieved, cfg)
    else:
        context = build_mixed_context(question, question_type, analysis, retrieved, cfg)

    return {
        'questionType': question_type,
        'context': context,
    }


def handle_chunk_document(cmd_data, cfg):
    """Chunk a document for RAG indexing."""
    doc = cmd_data['document']
    chunks = chunk_document(doc, cfg)
    return {'chunks': chunks, 'chunkCount': len(chunks)}


def handle_export_cleaned_csv(cmd_data, cfg):
    """Export cleaned tabular data as CSV.
    Re-parses and re-cleans the original file.
    """
    file_path = cmd_data.get('filePath', '')
    file_format = cmd_data.get('format', '')
    category = cmd_data.get('category', 'TABULAR')

    if not file_path or not os.path.exists(file_path):
        raise ValueError('Original file not found')

    # Re-parse
    df, _ = _parse_tabular(file_path, file_format, cfg)
    if df is None:
        raise ValueError('Cannot parse file for export')

    # Re-clean
    from cleaning.cleaner import clean_dataframe
    df_clean, _ = clean_dataframe(df, cfg)

    import io
    buffer = io.StringIO()
    df_clean.to_csv(buffer, index=False)
    csv_data = buffer.getvalue()
    return {'csv': csv_data}


COMMANDS = {
    'parse': handle_parse,
    'analyze': handle_analyze,
    'document_analyze': handle_document_analyze,
    'retrieve': handle_retrieve,
    'build_context': handle_build_context,
    'chunk_document': handle_chunk_document,
    'export_cleaned_csv': handle_export_cleaned_csv,
}


def main():
    """
    Main entry point. Reads JSON from stdin, processes, writes JSON to stdout.
    """
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            json.dump({'error': 'No input provided'}, sys.stdout)
            sys.stdout.flush()
            return

        data = json.loads(raw)
        command = data.get('command', '')

        if command not in COMMANDS:
            json.dump({'error': f'Unknown command: {command}'}, sys.stdout)
            sys.stdout.flush()
            return

        cfg = get_config()
        handler = COMMANDS[command]
        result = handler(data, cfg)

        json.dump({'success': True, 'data': result}, sys.stdout, ensure_ascii=False, default=str)
        sys.stdout.flush()

    except SystemExit:
        raise
    except Exception as e:
        tb = traceback.format_exc()
        sys.stderr.write(tb)
        sys.stderr.flush()
        json.dump({
            'error': str(e),
        }, sys.stdout)
        sys.stdout.flush()


if __name__ == '__main__':
    main()
