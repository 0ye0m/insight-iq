import pandas as pd
import numpy as np


def profile_dataset(df, cfg):
    """
    Generate column profiles: data type, missing count, unique count,
    sample values, and basic distribution info.
    """
    profiles = {}

    for col in df.columns:
        col_data = df[col]
        profile = {
            'column': col,
            'dtype': str(col_data.dtype),
            'totalValues': len(col_data),
            'missingCount': int(col_data.isna().sum()),
            'missingPercentage': round(col_data.isna().sum() / len(col_data) * 100, 2),
            'uniqueCount': int(col_data.nunique()),
            'topValues': [],
        }

        # Top values (for categorical-like)
        if profile['uniqueCount'] <= 50:
            value_counts = col_data.value_counts().head(10)
            profile['topValues'] = [
                {'value': str(v), 'count': int(c), 'percentage': round(c / len(col_data) * 100, 2)}
                for v, c in value_counts.items()
            ]

        profiles[col] = profile

    return profiles
