import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { fetchAnalysis, analyzeFile } from '@/api/client';
import { useHistoryStore } from '@/store/useStore';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import EmptyState from '@/components/ui/EmptyState';
import AnalysisOverview from '@/components/features/analysis/AnalysisOverview';
import StatisticsTable from '@/components/features/analysis/StatisticsTable';
import CorrelationMatrix from '@/components/features/analysis/CorrelationMatrix';
import DistributionChart from '@/components/features/analysis/DistributionChart';
import KpiCards from '@/components/features/analysis/KpiCards';
import InsightsPanel from '@/components/features/analysis/InsightsPanel';
import ExportButtons from '@/components/features/export/ExportButtons';
import { useToast } from '@/components/layout/ToastContainer';
import { ArrowLeft, Play, FileText } from 'lucide-react';
import type { AnalysisData, ApiError } from '@/types';

export default function AnalyzePage() {
  const { fileId } = useParams<{ fileId: string }>();

  if (!fileId) {
    return <AnalyzeFilePicker />;
  }

  return <AnalyzeView key={fileId} fileId={fileId} />;
}

/* ─── File Picker (no fileId in URL) ─── */
function AnalyzeFilePicker() {
  const { history } = useHistoryStore();
  const navigate = useNavigate();
  const completed = history.filter((h) => h.status === 'completed');

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-surface-50">Analyze</h2>
        <p className="mt-1 text-sm text-surface-500">
          Select a file to view analysis results
        </p>
      </div>
      {completed.length === 0 ? (
        <EmptyState
          type="no-data"
          title="No analyzed files"
          description="Upload a file and analyze it first"
          action={
            <Link to="/upload" className="btn-primary">
              <FileText className="h-4 w-4" /> Upload File
            </Link>
          }
        />
      ) : (
        <div className="space-y-2">
          {completed.map((item) => (
            <button
              key={item.fileId}
              onClick={() => navigate(`/analyze/${item.fileId}`)}
              className="card-interactive w-full flex items-center gap-4"
            >
              <FileText className="h-5 w-5 text-primary-400" />
              <div className="text-left flex-1">
                <p className="text-sm font-medium text-surface-200">{item.fileName}</p>
                <p className="text-xs text-surface-500">
                  {item.rowCount ? `${item.rowCount} rows` : ''}
                  {item.rowCount && item.columnCount ? ' · ' : ''}
                  {item.columnCount ? `${item.columnCount} columns` : ''}
                </p>
              </div>
              <span className="badge badge-green">completed</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─── Analysis View (with fileId) ─── */
function AnalyzeView({ fileId }: { fileId: string }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { update: updateHistory } = useHistoryStore();

  const [analysis, setAnalysis] = useState<AnalysisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const mountedRef = useRef(true);
  // Guard against React StrictMode double-invocation
  const analyzeTriggeredRef = useRef(false);

  // Poll until analysis is ready (used when 409 race occurs)
  const pollForAnalysis = useCallback((id: string) => {
    const interval = setInterval(async () => {
      if (!mountedRef.current) {
        clearInterval(interval);
        return;
      }
      try {
        const data = await fetchAnalysis(id);
        if (mountedRef.current) {
          setAnalysis(data);
          setAnalyzing(false);
          clearInterval(interval);
          updateHistory(id, {
            status: 'completed',
            analyzedAt: new Date().toISOString(),
            fileType: data.fileType,
            rowCount: data.rowCount ?? data.totalRows,
            columnCount: data.columnCount ?? data.totalColumns,
          });
        }
      } catch {
        // Still analyzing, keep polling
      }
    }, 2000);
  }, [updateHistory]);

  // Load analysis or auto-trigger it
  const loadOrAnalyze = useCallback(async () => {
    // Prevent double-fire from React StrictMode
    if (analyzeTriggeredRef.current) return;
    analyzeTriggeredRef.current = true;

    setLoading(true);
    setError(null);

    // Step 1: Try to get cached analysis
    try {
      const data = await fetchAnalysis(fileId);
      if (mountedRef.current) {
        setAnalysis(data);
        setLoading(false);
      }
      return;
    } catch (err) {
      const apiErr = err as ApiError;
      // If it's a 404, the file exists but isn't analyzed yet — that's fine
      // If it's any other error (network, 500, etc.), show error
      if (apiErr?.error?.code !== 'FILE_NOT_FOUND') {
        if (mountedRef.current) {
          setError(apiErr);
          setLoading(false);
        }
        return;
      }
      // 404 → fall through to analyze
    }

    // Step 2: No cached analysis → trigger analysis
    try {
      if (mountedRef.current) setAnalyzing(true);
      const result = await analyzeFile(fileId);
      if (mountedRef.current) {
        setAnalysis(result);
        setLoading(false);
        setAnalyzing(false);
        updateHistory(fileId, {
          status: 'completed',
          analyzedAt: new Date().toISOString(),
          fileType: result.fileType,
          rowCount: result.rowCount ?? result.totalRows,
          columnCount: result.columnCount ?? result.totalColumns,
        });
      }
    } catch (err) {
      if (mountedRef.current) {
        const apiErr = err as ApiError;
        // 409 = already analyzing (StrictMode race) — just wait for it
        if (apiErr?.error?.code === 'PROCESSING_IN_PROGRESS') {
          setError(null);
          setAnalyzing(true);
          setLoading(false);
          pollForAnalysis(fileId);
          return;
        }
        setError(apiErr);
        setLoading(false);
        setAnalyzing(false);
      }
    }
  }, [fileId, updateHistory, pollForAnalysis]);

  useEffect(() => {
    mountedRef.current = true;
    analyzeTriggeredRef.current = false;
    loadOrAnalyze();
    return () => { mountedRef.current = false; };
  }, [loadOrAnalyze]);

  const handleReanalyze = async () => {
    setAnalyzing(true);
    setError(null);
    try {
      const result = await analyzeFile(fileId);
      if (mountedRef.current) {
        setAnalysis(result);
        setAnalyzing(false);
        toast('success', 'Analysis refreshed');
        updateHistory(fileId, {
          status: 'completed',
          analyzedAt: new Date().toISOString(),
          fileType: result.fileType,
          rowCount: result.rowCount ?? result.totalRows,
          columnCount: result.columnCount ?? result.totalColumns,
        });
      }
    } catch (err) {
      if (mountedRef.current) {
        setError(err as ApiError);
        setAnalyzing(false);
        toast('error', 'Analysis failed');
      }
    }
  };

  // Loading state
  if (loading || analyzing) {
    return (
      <div className="mx-auto max-w-5xl">
        <LoadingSpinner
          size="lg"
          text={analyzing ? 'Running analysis on your data...' : 'Loading analysis...'}
          className="py-32"
        />
      </div>
    );
  }

  // Error state
  if (error || !analysis) {
    const isPythonError = error?.error?.code === 'PYTHON_ENGINE_UNAVAILABLE';
    return (
      <div className="mx-auto max-w-3xl">
        <EmptyState
          type="error"
          title={isPythonError ? 'Python Analytics Engine Required' : 'Analysis failed'}
          description={
            isPythonError
              ? 'The Python analytics engine is not available on the server. Analysis requires Python 3.9+ with pandas, numpy, and scipy installed.'
              : error?.error?.message ||
                'This file may have expired or could not be processed.'
          }
          action={
            <div className="flex flex-col gap-3 sm:flex-row">
              {isPythonError && (
                <div className="card w-full bg-surface-800/50 p-4 text-sm text-surface-400">
                  <p className="mb-2 font-medium text-surface-200">Setup steps:</p>
                  <ol className="list-inside list-decimal space-y-1">
                    <li>Install <a href="https://www.python.org/downloads/" target="_blank" rel="noreferrer" className="text-primary-400 underline hover:text-primary-300">Python 3.9+</a></li>
                    <li>Open terminal in <code className="rounded bg-surface-700 px-1.5 py-0.5 text-xs">insightai-backend/</code></li>
                    <li>Run: <code className="rounded bg-surface-700 px-1.5 py-0.5 text-xs">pip install -r requirements.txt</code></li>
                    <li>Restart the backend server</li>
                  </ol>
                </div>
              )}
              <div className="flex gap-3">
                <button onClick={() => navigate('/')} className="btn-secondary">
                  <ArrowLeft className="h-4 w-4" /> Go Back
                </button>
                {!isPythonError && (
                  <button onClick={handleReanalyze} className="btn-primary">
                    <Play className="h-4 w-4" /> Retry Analysis
                  </button>
                )}
              </div>
            </div>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      {/* Breadcrumb + actions */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="btn-ghost">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <h2 className="text-lg font-bold text-surface-50">{analysis.fileName}</h2>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="badge badge-blue">{analysis.fileType}</span>
              <span className="text-xs text-surface-500">{analysis.format}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={handleReanalyze} className="btn-secondary" disabled={analyzing}>
            <Play className="h-4 w-4" /> {analyzing ? 'Analyzing...' : 'Re-analyze'}
          </button>
          <Link to={`/chat/${fileId}`} className="btn-primary">
            Chat with Data
          </Link>
        </div>
      </div>

      {/* Overview stats */}
      <AnalysisOverview analysis={analysis} />

      {/* AI Insights */}
      <InsightsPanel analysis={analysis} />

      {/* KPIs */}
      <KpiCards analysis={analysis} />

      {/* Distribution chart */}
      <DistributionChart analysis={analysis} />

      {/* Statistics table (tabular only) */}
      {analysis.fileType === 'TABULAR' && <StatisticsTable analysis={analysis} />}

      {/* Correlation matrix (tabular only) */}
      {analysis.fileType === 'TABULAR' && <CorrelationMatrix analysis={analysis} />}

      {/* Export buttons */}
      <div className="card">
        <h3 className="section-title">Export</h3>
        <ExportButtons fileId={fileId} analysis={analysis} />
      </div>
    </div>
  );
}
