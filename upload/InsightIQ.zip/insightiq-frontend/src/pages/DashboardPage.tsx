import { useNavigate } from 'react-router-dom';
import { Upload, BarChart3, MessageSquare, Clock, Trash2, FileText } from 'lucide-react';
import { useHistoryStore } from '@/store/useStore';
import { fetchHealth } from '@/api/client';
import { useFetch } from '@/hooks/useApi';
import EmptyState from '@/components/ui/EmptyState';
import StatCard from '@/components/ui/StatCard';
import { timeAgo, formatNumber } from '@/utils/format';
import clsx from 'clsx';

export default function DashboardPage() {
  const { history, remove } = useHistoryStore();
  const navigate = useNavigate();
  const { data: health } = useFetch(fetchHealth, [], { enabled: true });

  const completedCount = history.filter((h) => h.status === 'completed').length;
  const totalRows = history.reduce((sum, h) => sum + (h.rowCount ?? 0), 0);

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Page header */}
      <div>
        <h2 className="text-2xl font-bold text-surface-50">Dashboard</h2>
        <p className="mt-1 text-sm text-surface-500">
          Overview of your data analysis workspace
        </p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          label="Files Analyzed"
          value={completedCount}
          icon={<FileText className="h-5 w-5" />}
        />
        <StatCard
          label="Total Rows Processed"
          value={formatNumber(totalRows)}
          icon={<BarChart3 className="h-5 w-5" />}
        />
        <StatCard
          label="Backend"
          value={health?.status === 'healthy' ? 'Online' : 'Offline'}
          icon={
            <div className={health?.status === 'healthy' ? 'text-emerald-400' : 'text-red-400'}>
              <div className="h-3 w-3 rounded-full bg-current" />
            </div>
          }
        />
        <StatCard
          label="AI Engine"
          value={health?.openRouter === 'configured' ? 'Ready' : 'Not Set'}
          icon={
            <div className={health?.openRouter === 'configured' ? 'text-emerald-400' : 'text-amber-400'}>
              <div className="h-3 w-3 rounded-full bg-current" />
            </div>
          }
        />
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <button
          onClick={() => navigate('/upload')}
          className="card-interactive flex items-center gap-4"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-600/10 text-primary-400">
            <Upload className="h-5 w-5" />
          </div>
          <div className="text-left">
            <p className="text-sm font-medium text-surface-200">Upload File</p>
            <p className="text-xs text-surface-500">CSV, Excel, PDF, and more</p>
          </div>
        </button>
        <button
          onClick={() => navigate('/chat')}
          className="card-interactive flex items-center gap-4"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-600/10 text-primary-400">
            <MessageSquare className="h-5 w-5" />
          </div>
          <div className="text-left">
            <p className="text-sm font-medium text-surface-200">Chat with Data</p>
            <p className="text-xs text-surface-500">Ask questions in natural language</p>
          </div>
        </button>
        <button
          onClick={() => navigate('/analyze')}
          className="card-interactive flex items-center gap-4"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-600/10 text-primary-400">
            <BarChart3 className="h-5 w-5" />
          </div>
          <div className="text-left">
            <p className="text-sm font-medium text-surface-200">View Analysis</p>
            <p className="text-xs text-surface-500">Explore statistics and insights</p>
          </div>
        </button>
      </div>

      {/* Recent History */}
      <div className="card !p-0 overflow-hidden">
        <div className="border-b border-surface-800 px-5 py-4 flex items-center justify-between">
          <h3 className="section-title !mb-0">Recent Files</h3>
          {history.length > 0 && (
            <button onClick={() => remove(history[0].fileId)} className="btn-ghost text-xs">
              Clear all
            </button>
          )}
        </div>

        {history.length === 0 ? (
          <EmptyState
            type="no-data"
            title="No files yet"
            description="Upload a file to get started with data analysis"
          />
        ) : (
          <div className="divide-y divide-surface-800/50">
            {history.map((item) => (
              <div
                key={item.fileId}
                className="flex items-center gap-4 px-5 py-3 hover:bg-surface-800/30 transition-colors"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-surface-800 text-surface-400">
                  <FileText className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p
                    className="text-sm font-medium text-surface-200 truncate cursor-pointer hover:text-primary-400 transition-colors"
                    onClick={() => navigate(`/analyze/${item.fileId}`)}
                  >
                    {item.fileName}
                  </p>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-surface-500">
                    <span className={clsx(
                      'badge text-[10px]',
                      item.status === 'completed' && 'badge-green',
                      item.status === 'failed' && 'badge-red',
                      item.status === 'processing' && 'badge-amber',
                      (item.status === 'uploaded' || item.status === 'expired') && 'badge-blue',
                    )}>
                      {item.status}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {timeAgo(item.uploadedAt)}
                    </span>
                    {item.rowCount && (
                      <span>{formatNumber(item.rowCount)} rows</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => navigate(`/analyze/${item.fileId}`)}
                    className="btn-ghost text-xs"
                  >
                    View
                  </button>
                  <button
                    onClick={() => remove(item.fileId)}
                    className="btn-ghost text-xs text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
