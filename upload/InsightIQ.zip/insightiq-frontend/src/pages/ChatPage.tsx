import { useParams, useNavigate, Link } from 'react-router-dom';
import { useEffect } from 'react';
import ChatPanel from '@/components/features/chat/ChatPanel';
import { fetchAnalysis } from '@/api/client';
import { useFetch } from '@/hooks/useApi';
import { useHistoryStore } from '@/store/useStore';
import EmptyState from '@/components/ui/EmptyState';
import { MessageSquare, FileText } from 'lucide-react';

export default function ChatPage() {
  const { fileId } = useParams<{ fileId: string }>();

  if (!fileId) {
    return <ChatFilePicker />;
  }

  return <ChatView key={fileId} fileId={fileId} />;
}

/* ─── File Picker ─── */
function ChatFilePicker() {
  const { history } = useHistoryStore();
  const navigate = useNavigate();

  const completed = history.filter((h) => h.status === 'completed');

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-surface-50">Chat with Data</h2>
        <p className="mt-1 text-sm text-surface-500">
          Select a file to start asking questions
        </p>
      </div>

      {completed.length === 0 ? (
        <EmptyState
          type="no-data"
          title="No analyzed files"
          description="Upload and analyze a file first, then come back to chat"
          action={
            <Link to="/upload" className="btn-primary">
              <FileText className="h-4 w-4" /> Upload File
            </Link>
          }
        />
      ) : (
        <div className="space-y-2">
          {completed.map((item) => (
            <button
              key={item.fileId}
              onClick={() => navigate(`/chat/${item.fileId}`)}
              className="card-interactive w-full flex items-center gap-4"
            >
              <MessageSquare className="h-5 w-5 text-primary-400" />
              <div className="text-left flex-1">
                <p className="text-sm font-medium text-surface-200">{item.fileName}</p>
                <p className="text-xs text-surface-500">
                  {item.rowCount ? `${item.rowCount} rows` : ''}
                </p>
              </div>
              <span className="badge badge-green">ready</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─── Chat View ─── */
function ChatView({ fileId }: { fileId: string }) {
  const navigate = useNavigate();
  const { data: analysis } = useFetch(() => fetchAnalysis(fileId), [fileId]);

  // Update history status when analysis loads
  const { update: updateHistory } = useHistoryStore();
  useEffect(() => {
    if (analysis) {
      updateHistory(fileId, {
        status: 'completed',
        fileType: analysis.fileType,
        rowCount: analysis.rowCount ?? analysis.totalRows,
        columnCount: analysis.columnCount ?? analysis.totalColumns,
      });
    }
  }, [analysis, fileId, updateHistory]);

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-4 flex items-center gap-3">
        <button
          onClick={() => navigate('/')}
          className="btn-ghost"
        >
          ← Back
        </button>
        <h2 className="text-lg font-bold text-surface-50">Chat</h2>
      </div>

      <div className="card !p-0 overflow-hidden" style={{ height: 'calc(100vh - 180px)', minHeight: 400 }}>
        <ChatPanel
          fileId={fileId}
          fileName={analysis?.fileName}
        />
      </div>
    </div>
  );
}