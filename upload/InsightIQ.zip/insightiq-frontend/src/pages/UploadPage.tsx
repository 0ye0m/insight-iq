import UploadZone from '@/components/features/upload/UploadZone';

export default function UploadPage() {
  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-surface-50">Upload File</h2>
        <p className="mt-1 text-sm text-surface-500">
          Drop any data file to begin automated analysis
        </p>
      </div>
      <UploadZone />
    </div>
  );
}
