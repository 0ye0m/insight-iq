import axios from 'axios';
import type { ApiResponse, ApiError } from '@/types';

const api = axios.create({
  baseURL: '/api',
  timeout: 120_000,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const apiErr: ApiError = error.response?.data ?? {
      success: false,
      error: {
        code: 'NETWORK_ERROR',
        message: error.message || 'Network error. Is the backend running on port 5000?',
      },
    };
    return Promise.reject(apiErr);
  },
);

export default api;

/* ─── Health ─── */
export async function fetchHealth() {
  const { data } = await api.get<ApiResponse<import('@/types').HealthData>>('/health');
  return data.data;
}

/* ─── Upload ─── */
export async function uploadFile(file: File) {
  const form = new FormData();
  form.append('file', file);
  const { data } = await api.post<ApiResponse<import('@/types').UploadResult>>(
    '/files/upload',
    form,
    { headers: { 'Content-Type': 'multipart/form-data' } },
  );
  return data.data;
}

/* ─── Analyze ─── */
export async function analyzeFile(fileId: string) {
  const { data } = await api.post<ApiResponse<import('@/types').AnalysisData>>(
    `/files/${fileId}/analyze`,
  );
  return data.data;
}

/* ─── Status ─── */
export async function fetchStatus(fileId: string) {
  const { data } = await api.get<ApiResponse<import('@/types').FileStatusData>>(
    `/files/${fileId}/status`,
  );
  return data.data;
}

/* ─── Get Analysis ─── */
export async function fetchAnalysis(fileId: string) {
  const { data } = await api.get<ApiResponse<import('@/types').AnalysisData>>(
    `/files/${fileId}/analysis`,
  );
  return data.data;
}

/* ─── Chat ─── */
export async function sendChat(fileId: string, question: string) {
  const { data } = await api.post<ApiResponse<import('@/types').ChatResponse>>(
    `/files/${fileId}/chat`,
    { question },
  );
  return data.data;
}

/* ─── Export Cleaned CSV ─── */
export async function exportCleanedCsv(fileId: string) {
  const response = await api.get(`/files/${fileId}/export/cleaned`, {
    responseType: 'blob',
  });
  downloadBlob(response.data, `cleaned_${fileId}.csv`);
}

/* ─── Export Report XLSX ─── */
export async function exportReport(fileId: string) {
  const response = await api.get(`/files/${fileId}/export/report`, {
    responseType: 'blob',
  });
  downloadBlob(response.data, `insightai_report_${fileId}.xlsx`);
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
