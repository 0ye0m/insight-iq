import { useState, useEffect, useCallback, useRef } from 'react';
import type { ApiError } from '@/types';

interface AsyncState<T> {
  data: T | null;
  loading: boolean;
  error: ApiError | null;
}

/**
 * Generic async hook — no TanStack, no BS.
 * Uses a ref for the fn to avoid stale closures and infinite re-render loops.
 */
export function useFetch<T>(
  fn: () => Promise<T>,
  deps: unknown[] = [],
  options: { enabled?: boolean; refetchInterval?: number } = {},
): AsyncState<T> & { refetch: () => void } {
  const { enabled = true, refetchInterval } = options;
  const [state, setState] = useState<AsyncState<T>>({
    data: null,
    loading: enabled,
    error: null,
  });
  const mountedRef = useRef(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  // Store fn in a ref so the effect doesn't re-trigger on every fn reference change
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;

  const fetchData = useCallback(() => {
    if (!enabledRef.current) return;
    setState((prev) => ({ ...prev, loading: true, error: null }));
    fnRef
      .current()
      .then((data) => {
        if (mountedRef.current) setState({ data, loading: false, error: null });
      })
      .catch((err) => {
        if (mountedRef.current) setState({ data: null, loading: false, error: err });
      });
  }, []); // stable — never recreates

  useEffect(() => {
    mountedRef.current = true;
    fetchData();
    if (refetchInterval && refetchInterval > 0) {
      intervalRef.current = setInterval(fetchData, refetchInterval);
    }
    return () => {
      mountedRef.current = false;
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [...deps]); // only re-run when deps change, NOT when fetchData changes

  return { ...state, refetch: fetchData };
}

/**
 * Imperative mutation hook for POST/PUT operations.
 */
export function useMutation<TArgs extends unknown[], TResult>(
  fn: (...args: TArgs) => Promise<TResult>,
) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);

  const mutate = useCallback(
    async (...args: TArgs): Promise<TResult | null> => {
      setLoading(true);
      setError(null);
      try {
        const result = await fn(...args);
        return result;
      } catch (err) {
        setError(err as ApiError);
        return null;
      } finally {
        setLoading(false);
      }
    },
    [fn],
  );

  return { mutate, loading, error };
}
