import { useState, useCallback, useEffect } from 'react';
import type { ProcessingHistoryItem } from '@/types';

const STORAGE_KEY = 'insightiq_history';

function loadHistory(): ProcessingHistoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveHistory(items: ProcessingHistoryItem[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, 50)));
}

export function useHistoryStore() {
  const [history, setHistory] = useState<ProcessingHistoryItem[]>(loadHistory);

  useEffect(() => {
    saveHistory(history);
  }, [history]);

  const add = useCallback((item: ProcessingHistoryItem) => {
    setHistory((prev) => {
      const filtered = prev.filter((h) => h.fileId !== item.fileId);
      return [item, ...filtered];
    });
  }, []);

  const update = useCallback((fileId: string, patch: Partial<ProcessingHistoryItem>) => {
    setHistory((prev) =>
      prev.map((h) => (h.fileId === fileId ? { ...h, ...patch } : h)),
    );
  }, []);

  const remove = useCallback((fileId: string) => {
    setHistory((prev) => prev.filter((h) => h.fileId !== fileId));
  }, []);

  const clear = useCallback(() => setHistory([]), []);

  return { history, add, update, remove, clear };
}
