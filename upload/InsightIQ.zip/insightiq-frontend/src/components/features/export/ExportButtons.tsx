import { useState } from 'react';
import { Download, FileSpreadsheet, FileText } from 'lucide-react';
import { exportCleanedCsv, exportReport } from '@/api/client';
import { useToast } from '@/components/layout/ToastContainer';
import type { AnalysisData } from '@/types';

interface Props {
  fileId: string;
  analysis: AnalysisData;
}

export default function ExportButtons({ fileId, analysis }: Props) {
  const [exporting, setExporting] = useState<string | null>(null);
  const { toast } = useToast();
  const isTabular = analysis.fileType === 'TABULAR';

  const handleExportCsv = async () => {
    setExporting('csv');
    try {
      await exportCleanedCsv(fileId);
      toast('success', 'Cleaned CSV downloaded');
    } catch {
      toast('error', 'Failed to export cleaned data');
    } finally {
      setExporting(null);
    }
  };

  const handleExportReport = async () => {
    setExporting('report');
    try {
      await exportReport(fileId);
      toast('success', 'Excel report downloaded');
    } catch {
      toast('error', 'Failed to export report');
    } finally {
      setExporting(null);
    }
  };

  return (
    <div className="flex flex-wrap gap-3">
      {isTabular && (
        <button
          onClick={handleExportCsv}
          disabled={exporting !== null}
          className="btn-secondary"
        >
          <FileText className="h-4 w-4" />
          {exporting === 'csv' ? 'Exporting...' : 'Export Cleaned CSV'}
        </button>
      )}
      <button
        onClick={handleExportReport}
        disabled={exporting !== null}
        className="btn-secondary"
      >
        <FileSpreadsheet className="h-4 w-4" />
        {exporting === 'report' ? 'Exporting...' : 'Export Excel Report'}
      </button>
    </div>
  );
}
