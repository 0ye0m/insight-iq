import type { AnalysisData } from '@/types';
import { Target, TrendingUp, AlertTriangle, Zap } from 'lucide-react';

interface Props {
  analysis: AnalysisData;
}

export default function KpiCards({ analysis }: Props) {
  const kpis = analysis.kpi;
  if (!kpis || kpis.length === 0) return null;

  const iconMap: Record<string, typeof Target> = {
    default: Target,
    trend: TrendingUp,
    alert: AlertTriangle,
    highlight: Zap,
  };

  return (
    <div className="card">
      <h3 className="section-title">Key Performance Indicators</h3>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {kpis.map((kpi, i) => {
          const Icon = iconMap.default;
          return (
            <div
              key={i}
              className="rounded-lg border border-surface-800 bg-surface-800/50 p-4"
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon className="h-4 w-4 text-primary-400" />
                <span className="text-sm font-medium text-surface-200">{kpi.name}</span>
              </div>
              <p className="text-xl font-bold text-surface-50">{kpi.value}</p>
              {kpi.description && (
                <p className="mt-1 text-xs text-surface-500 leading-relaxed">{kpi.description}</p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
