import type { AnalysisData } from '@/types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface Props {
  analysis: AnalysisData;
}

export default function DistributionChart({ analysis }: Props) {
  const stats = analysis.statistics;
  if (!stats) return null;

  // Find first numeric column with top values OR build from stats
  const numericCol = Object.entries(stats).find(
    ([_, s]) => s.dataType === 'numeric' || s.dataType === 'integer' || s.dataType === 'float',
  );

  // Find first categorical column with top values for bar chart
  const categoricalCol = Object.entries(stats).find(
    ([_, s]) => s.topValues && s.topValues.length > 0,
  );

  const chartData = categoricalCol
    ? categoricalCol[1].topValues!.slice(0, 10).map((v) => ({
        name: v.value.length > 15 ? v.value.slice(0, 12) + '...' : v.value,
        value: v.count,
        pct: v.pct,
      }))
    : numericCol
      ? buildHistogramData(numericCol[1])
      : null;

  if (!chartData || chartData.length === 0) return null;

  const columnLabel = categoricalCol ? categoricalCol[0] : numericCol ? numericCol[0] : 'Value';

  return (
    <div className="card">
      <h3 className="section-title">Distribution — {columnLabel}</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 4, right: 4, bottom: 4, left: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
            <XAxis
              dataKey="name"
              tick={{ fill: '#64748b', fontSize: 11 }}
              axisLine={{ stroke: '#334155' }}
              tickLine={false}
              angle={-35}
              textAnchor="end"
              height={60}
            />
            <YAxis
              tick={{ fill: '#64748b', fontSize: 11 }}
              axisLine={{ stroke: '#334155' }}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#1e293b',
                border: '1px solid #334155',
                borderRadius: 8,
                color: '#e2e8f0',
                fontSize: 12,
              }}
            />
            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
              {chartData.map((_, i) => (
                <Cell
                  key={i}
                  fill={`hsl(${230 + i * 8}, 70%, ${55 + i * 2}%)`}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function buildHistogramData(stats: { min?: number; max?: number; mean?: number; std?: number }) {
  if (stats.min === undefined || stats.max === undefined) return [];
  const range = stats.max - stats.min;
  const binCount = Math.min(12, Math.max(5, Math.ceil(range / ((stats.std ?? 1) * 0.5))));
  const binWidth = range / binCount;
  const data = [];
  for (let i = 0; i < binCount; i++) {
    const low = stats.min + i * binWidth;
    const high = low + binWidth;
    data.push({
      name: `${low.toFixed(0)}`,
      value: Math.floor(Math.random() * 100 + 10), // placeholder
      pct: 0,
    });
  }
  return data;
}
