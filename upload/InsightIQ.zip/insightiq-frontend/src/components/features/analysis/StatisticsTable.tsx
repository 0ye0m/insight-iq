import type { AnalysisData, ColumnStats } from '@/types';
import { formatNumber } from '@/utils/format';

interface Props {
  analysis: AnalysisData;
}

export default function StatisticsTable({ analysis }: Props) {
  const stats = analysis.statistics;
  if (!stats) return null;

  const columns = Object.entries(stats);
  if (columns.length === 0) return null;

  return (
    <div className="card overflow-hidden !p-0">
      <div className="border-b border-surface-800 px-5 py-4">
        <h3 className="section-title !mb-0">Column Statistics</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-surface-800 text-left text-xs text-surface-500">
              <th className="px-5 py-3 font-medium">Column</th>
              <th className="px-5 py-3 font-medium">Type</th>
              <th className="px-5 py-3 font-medium text-right">Count</th>
              <th className="px-5 py-3 font-medium text-right">Nulls</th>
              <th className="px-5 py-3 font-medium text-right">Unique</th>
              <th className="px-5 py-3 font-medium text-right">Mean</th>
              <th className="px-5 py-3 font-medium text-right">Median</th>
              <th className="px-5 py-3 font-medium text-right">Std</th>
              <th className="px-5 py-3 font-medium text-right">Min</th>
              <th className="px-5 py-3 font-medium text-right">Max</th>
            </tr>
          </thead>
          <tbody>
            {columns.map(([name, s]) => (
              <StatRow key={name} name={name} stats={s} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatRow({ name, stats }: { name: string; stats: ColumnStats }) {
  const isNumeric = stats.dataType === 'numeric' || stats.dataType === 'integer' || stats.dataType === 'float';

  return (
    <tr className="border-b border-surface-800/50 last:border-0 hover:bg-surface-800/30">
      <td className="px-5 py-3 font-medium text-surface-200">{name}</td>
      <td className="px-5 py-3">
        <span className="badge badge-blue">{stats.dataType}</span>
      </td>
      <td className="px-5 py-3 text-right text-surface-300 tabular-nums">{formatNumber(stats.count)}</td>
      <td className="px-5 py-3 text-right tabular-nums">
        <span className={stats.nullCount > 0 ? 'text-amber-400' : 'text-surface-500'}>
          {formatNumber(stats.nullCount)}
        </span>
      </td>
      <td className="px-5 py-3 text-right text-surface-300 tabular-nums">{formatNumber(stats.unique)}</td>
      {isNumeric ? (
        <>
          <td className="px-5 py-3 text-right text-surface-300 tabular-nums">
            {stats.mean !== undefined ? stats.mean.toFixed(2) : '—'}
          </td>
          <td className="px-5 py-3 text-right text-surface-300 tabular-nums">
            {stats.median !== undefined ? stats.median.toFixed(2) : '—'}
          </td>
          <td className="px-5 py-3 text-right text-surface-300 tabular-nums">
            {stats.std !== undefined ? stats.std.toFixed(2) : '—'}
          </td>
          <td className="px-5 py-3 text-right text-surface-300 tabular-nums">
            {stats.min !== undefined ? formatNumber(stats.min) : '—'}
          </td>
          <td className="px-5 py-3 text-right text-surface-300 tabular-nums">
            {stats.max !== undefined ? formatNumber(stats.max) : '—'}
          </td>
        </>
      ) : (
        <td colSpan={5} className="px-5 py-3 text-center text-surface-500">
            Categorical
          </td>
      )}
    </tr>
  );
}
