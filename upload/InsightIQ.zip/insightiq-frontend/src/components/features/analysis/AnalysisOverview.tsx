import type { AnalysisData } from '@/types';
import { formatBytes, formatNumber, formatPercent } from '@/utils/format';
import StatCard from '@/components/ui/StatCard';
import {
  Table2,
  Hash,
  AlertTriangle,
  Clock,
  FileText,
  Columns3,
} from 'lucide-react';

interface Props {
  analysis: AnalysisData;
}

export default function AnalysisOverview({ analysis }: Props) {
  const isTabular = analysis.fileType === 'TABULAR';

  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      <StatCard
        label="File Type"
        value={analysis.format.toUpperCase()}
        icon={<FileText className="h-5 w-5" />}
      />
      <StatCard
        label={isTabular ? 'Rows' : 'Characters'}
        value={formatNumber(isTabular ? (analysis.rowCount ?? 0) : (analysis.textLength ?? 0))}
        icon={<Hash className="h-5 w-5" />}
      />
      {isTabular && (
        <>
          <StatCard
            label="Columns"
            value={formatNumber(analysis.columnCount ?? 0)}
            icon={<Columns3 className="h-5 w-5" />}
          />
          <StatCard
            label="Missing Data"
            value={formatPercent(analysis.missingPct ?? 0)}
            icon={<AlertTriangle className="h-5 w-5" />}
          />
        </>
      )}
      {analysis.duplicateRows !== undefined && (
        <StatCard
          label="Duplicate Rows"
          value={formatNumber(analysis.duplicateRows)}
          icon={<Table2 className="h-5 w-5" />}
        />
      )}
      {analysis.processingTime !== undefined && (
        <StatCard
          label="Processing Time"
          value={`${(analysis.processingTime / 1000).toFixed(1)}s`}
          icon={<Clock className="h-5 w-5" />}
        />
      )}
    </div>
  );
}
