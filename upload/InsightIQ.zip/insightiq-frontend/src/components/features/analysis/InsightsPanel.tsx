import type { AnalysisData } from '@/types';
import { severityColor } from '@/utils/format';
import { Lightbulb, AlertTriangle, Info, ChevronRight } from 'lucide-react';

interface Props {
  analysis: AnalysisData;
}

export default function InsightsPanel({ analysis }: Props) {
  const insights = analysis.insights;
  if (!insights || insights.length === 0) {
    if (!analysis.aiAvailable) {
      return (
        <div className="card">
          <h3 className="section-title">AI Insights</h3>
          <div className="flex items-center gap-3 rounded-lg border border-amber-500/20 bg-amber-500/5 p-4 text-sm text-amber-300">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>
              AI insights unavailable. Configure <code className="rounded bg-surface-800 px-1.5 py-0.5 text-xs">OPENROUTER_API_KEY</code> in your backend <code className="rounded bg-surface-800 px-1.5 py-0.5 text-xs">.env</code> to enable AI-powered insights.
            </span>
          </div>
        </div>
      );
    }
    return null;
  }

  return (
    <div className="card">
      <h3 className="section-title">AI Insights</h3>
      <div className="space-y-3">
        {insights.map((insight, i) => (
          <div
            key={i}
            className="flex gap-3 rounded-lg border border-surface-800 bg-surface-800/30 p-4"
          >
            <div className="mt-0.5">
              {insight.severity === 'high' ? (
                <AlertTriangle className="h-4 w-4 text-red-400" />
              ) : insight.type === 'pattern' ? (
                <Lightbulb className="h-4 w-4 text-amber-400" />
              ) : (
                <Info className="h-4 w-4 text-primary-400" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-medium text-surface-200">{insight.title}</span>
                {insight.severity && (
                  <span className={`badge ${severityColor(insight.severity)}`}>
                    {insight.severity}
                  </span>
                )}
              </div>
              <p className="text-sm text-surface-400 leading-relaxed">{insight.description}</p>
              {insight.columns && insight.columns.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {insight.columns.map((col) => (
                    <span key={col} className="badge badge-blue text-xs">{col}</span>
                  ))}
                </div>
              )}
            </div>
            <ChevronRight className="h-4 w-4 shrink-0 text-surface-600" />
          </div>
        ))}
      </div>
    </div>
  );
}
