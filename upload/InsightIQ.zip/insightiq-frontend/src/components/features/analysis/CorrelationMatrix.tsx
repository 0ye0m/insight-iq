import type { AnalysisData } from '@/types';
import { correlationColor, correlationBg } from '@/utils/format';

interface Props {
  analysis: AnalysisData;
}

export default function CorrelationMatrix({ analysis }: Props) {
  const corrs = analysis.correlations;
  if (!corrs || corrs.length === 0) return null;

  // Get unique column names
  const colSet = new Set<string>();
  corrs.forEach((c) => { colSet.add(c.col1); colSet.add(c.col2); });
  const cols = Array.from(colSet);

  // Build lookup map
  const map = new Map<string, number>();
  corrs.forEach((c) => { map.set(`${c.col1}|${c.col2}`, c.correlation); });

  return (
    <div className="card overflow-hidden !p-0">
      <div className="border-b border-surface-800 px-5 py-4">
        <h3 className="section-title !mb-0">Correlation Matrix</h3>
      </div>
      <div className="overflow-x-auto p-4">
        <table className="text-xs">
          <thead>
            <tr>
              <th className="px-2 py-2" />
              {cols.map((c) => (
                <th key={c} className="px-2 py-2 text-left font-medium text-surface-500">
                  <span className="max-w-[100px] truncate block">{c}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {cols.map((row) => (
              <tr key={row}>
                <td className="px-2 py-2 font-medium text-surface-500">
                  <span className="max-w-[100px] truncate block">{row}</span>
                </td>
                {cols.map((col) => {
                  if (row === col) {
                    return (
                      <td key={col} className="px-1 py-1">
                        <div className="flex h-8 w-16 items-center justify-center rounded bg-primary-600/20 text-primary-300 font-mono">
                          1.00
                        </div>
                      </td>
                    );
                  }
                  const val = map.get(`${row}|${col}`) ?? map.get(`${col}|${row}`);
                  const display = val !== undefined ? val.toFixed(2) : '—';
                  return (
                    <td key={col} className="px-1 py-1">
                      <div
                        className={`flex h-8 w-16 items-center justify-center rounded font-mono ${
                          val !== undefined ? correlationBg(val) : 'bg-surface-800/50'
                        } ${val !== undefined ? correlationColor(val) : 'text-surface-600'}`}
                      >
                        {display}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Legend */}
      <div className="border-t border-surface-800 px-5 py-3 flex items-center gap-4 text-xs text-surface-500">
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-6 rounded bg-emerald-500/20" /> Strong positive
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-6 rounded bg-red-500/20" /> Strong negative
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-6 rounded bg-surface-800" /> Weak
        </span>
      </div>
    </div>
  );
}
