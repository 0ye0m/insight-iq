import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { sendChat } from '@/api/client';
import { useToast } from '@/components/layout/ToastContainer';
import type { ChatResponse } from '@/types';

interface Message {
  id: number;
  role: 'user' | 'assistant';
  content: string;
}

interface Props {
  fileId: string;
  fileName?: string;
}

export default function ChatPanel({ fileId, fileName }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    const question = input.trim();
    if (!question || loading) return;

    const userMsg: Message = { id: Date.now(), role: 'user', content: question };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const result: ChatResponse = await sendChat(fileId, question);
      const assistantMsg: Message = {
        id: Date.now() + 1,
        role: 'assistant',
        content: result.answer,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      toast('error', 'Failed to get response. Is the AI configured?');
    } finally {
      setLoading(false);
    }
  };

  const suggestions = [
    'What are the main patterns in this data?',
    'Show me a summary of key statistics',
    'Are there any data quality issues?',
    'What correlations stand out?',
  ];

  return (
    <div className="flex h-full flex-col">
      {/* File context */}
      {fileName && (
        <div className="flex items-center gap-2 border-b border-surface-800 px-5 py-3">
          <Sparkles className="h-4 w-4 text-primary-400" />
          <span className="text-sm text-surface-400">
            Chatting about: <span className="text-surface-200 font-medium">{fileName}</span>
          </span>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-800">
              <Bot className="h-7 w-7 text-surface-500" />
            </div>
            <h3 className="text-base font-medium text-surface-300">Ask about your data</h3>
            <p className="mt-1 max-w-md text-sm text-surface-500">
              Use natural language to query insights, trends, and patterns in your uploaded file.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => setInput(s)}
                  className="btn-ghost text-xs"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}
          >
            {msg.role === 'assistant' && (
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary-600/10">
                <Bot className="h-4 w-4 text-primary-400" />
              </div>
            )}
            <div
              className={`max-w-[75%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-primary-600 text-white'
                  : 'bg-surface-800 text-surface-200'
              }`}
            >
              {msg.content}
            </div>
            {msg.role === 'user' && (
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-surface-700">
                <User className="h-4 w-4 text-surface-300" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex gap-3">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary-600/10">
              <Bot className="h-4 w-4 text-primary-400" />
            </div>
            <div className="rounded-xl bg-surface-800 px-4 py-3">
              <Loader2 className="h-4 w-4 animate-spin text-surface-400" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="border-t border-surface-800 p-4">
        <div className="flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Ask a question about your data..."
            className="input-field flex-1"
            disabled={loading}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className="btn-primary"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
