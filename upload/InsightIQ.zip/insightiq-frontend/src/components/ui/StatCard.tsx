import type { ReactNode } from 'react';
import clsx from 'clsx';

interface Props {
  label: string;
  value: string | number;
  icon?: ReactNode;
  trend?: { value: string; up: boolean };
  className?: string;
}

export default function StatCard({ label, value, icon, trend, className }: Props) {
  return (
    <div className={clsx('card', className)}>
      <div className="flex items-start justify-between">
        <div>
          <p className="stat-label">{label}</p>
          <p className="stat-value mt-2">{value}</p>
        </div>
        {icon && (
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-600/10 text-primary-400">
            {icon}
          </div>
        )}
      </div>
      {trend && (
        <p className={clsx('mt-3 text-xs font-medium', trend.up ? 'text-emerald-400' : 'text-red-400')}>
          {trend.up ? '↑' : '↓'} {trend.value}
        </p>
      )}
    </div>
  );
}
