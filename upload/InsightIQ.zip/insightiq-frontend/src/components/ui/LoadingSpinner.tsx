import { Loader2 } from 'lucide-react';
import clsx from 'clsx';

interface Props {
  size?: 'sm' | 'md' | 'lg';
  text?: string;
  className?: string;
}

export default function LoadingSpinner({ size = 'md', text, className }: Props) {
  return (
    <div className={clsx('flex flex-col items-center justify-center gap-3', className)}>
      <Loader2
        className={clsx(
          'animate-spin text-primary-400',
          size === 'sm' && 'h-4 w-4',
          size === 'md' && 'h-6 w-6',
          size === 'lg' && 'h-10 w-10',
        )}
      />
      {text && <span className="text-sm text-surface-400">{text}</span>}
    </div>
  );
}
