import { AlertCircle, FileQuestion, Inbox, ServerCrash } from 'lucide-react';
import type { ReactNode } from 'react';

interface Props {
  type?: 'no-data' | 'no-results' | 'error' | 'offline';
  title: string;
  description?: string;
  action?: ReactNode;
}

const ICONS = {
  'no-data': Inbox,
  'no-results': FileQuestion,
  'error': AlertCircle,
  'offline': ServerCrash,
} as const;

export default function EmptyState({ type = 'no-data', title, description, action }: Props) {
  const Icon = ICONS[type];
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-800">
        <Icon className="h-7 w-7 text-surface-500" />
      </div>
      <h3 className="text-base font-medium text-surface-300">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-surface-500">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
