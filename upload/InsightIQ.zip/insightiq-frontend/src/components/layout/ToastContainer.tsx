import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { X, CheckCircle, AlertTriangle, XCircle, Info } from 'lucide-react';
import clsx from 'clsx';

type ToastType = 'success' | 'error' | 'warning' | 'info';

interface Toast {
  id: number;
  type: ToastType;
  message: string;
}

interface ToastContextValue {
  toast: (type: ToastType, message: string) => void;
}

const ToastContext = createContext<ToastContextValue>({ toast: () => {} });
export const useToast = () => useContext(ToastContext);

let toastId = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = useCallback((type: ToastType, message: string) => {
    const id = ++toastId;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4000);
  }, []);

  const removeToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ toast: addToast }}>
      {children}
      <ToastContainerInner toasts={toasts} onRemove={removeToast} />
    </ToastContext.Provider>
  );
}

function ToastContainerInner({
  toasts,
  onRemove,
}: {
  toasts: Toast[];
  onRemove: (id: number) => void;
}) {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={clsx(
            'flex items-center gap-3 rounded-lg border px-4 py-3 shadow-lg text-sm animate-[slideUp_0.2s_ease]',
            t.type === 'success' && 'border-emerald-500/30 bg-surface-900 text-emerald-300',
            t.type === 'error' && 'border-red-500/30 bg-surface-900 text-red-300',
            t.type === 'warning' && 'border-amber-500/30 bg-surface-900 text-amber-300',
            t.type === 'info' && 'border-primary-500/30 bg-surface-900 text-primary-300',
          )}
        >
          {t.type === 'success' && <CheckCircle className="h-4 w-4 shrink-0" />}
          {t.type === 'error' && <XCircle className="h-4 w-4 shrink-0" />}
          {t.type === 'warning' && <AlertTriangle className="h-4 w-4 shrink-0" />}
          {t.type === 'info' && <Info className="h-4 w-4 shrink-0" />}
          <span className="flex-1">{t.message}</span>
          <button onClick={() => onRemove(t.id)} className="text-surface-500 hover:text-surface-300">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}

// Re-exported as component for AppShell
export function ToastContainer() {
  // This is a no-op placeholder — actual toasts are rendered by ToastProvider
  return null;
}
