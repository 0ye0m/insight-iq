import { Activity, Wifi, WifiOff, AlertTriangle } from 'lucide-react';
import { fetchHealth } from '@/api/client';
import { useFetch } from '@/hooks/useApi';

type HeaderProps = {
  title?: string;
};

export default function Header({ title }: HeaderProps) {
  const { data: health } = useFetch(fetchHealth, [], { refetchInterval: 30_000 });

  const isHealthy = health?.status === 'healthy';
  const pythonOk = health?.analyticsEngine === 'available';

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-surface-800 bg-surface-900/50 px-6">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 md:hidden">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary-600">
            <Activity className="h-3.5 w-3.5 text-white" />
          </div>
          <span className="text-sm font-semibold text-surface-100">InsightIQ</span>
        </div>
        {title && <h1 className="text-sm font-medium text-surface-300">{title}</h1>}
      </div>

      <div className="flex items-center gap-4">
        {/* Python engine warning */}
        {health && !pythonOk && (
          <div className="flex items-center gap-1.5 rounded-md bg-amber-500/10 px-2.5 py-1 text-xs text-amber-400" title={
            health.analyticsEngine === 'unavailable'
              ? `Python not found (tried: ${health.analyticsPythonPath}). Install Python 3.9+ and run: pip install -r requirements.txt`
              : `Analytics script not found at expected path.`
          }>
            <AlertTriangle className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Python Missing</span>
          </div>
        )}

        {/* Connection status */}
        <div className="flex items-center gap-2 text-xs">
          <span className={isHealthy ? 'text-emerald-400' : 'text-amber-400'}>
            {isHealthy ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
          </span>
          <span className={isHealthy ? 'text-emerald-400' : 'text-amber-400'}>
            {isHealthy ? 'Connected' : 'Degraded'}
          </span>
        </div>

        {/* Backend features */}
        {health && (
          <div className="hidden items-center gap-3 text-xs text-surface-500 sm:flex">
            <span className={pythonOk ? 'text-emerald-400/70' : 'text-amber-400/70'}>
              Analytics
            </span>
            <span className={health.ocr === 'available' ? 'text-emerald-400/70' : ''}>
              OCR
            </span>
            <span className={health.openRouter === 'configured' ? 'text-emerald-400/70' : ''}>
              AI
            </span>
          </div>
        )}
      </div>
    </header>
  );
}
