import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ToastProvider } from '@/components/layout/ToastContainer';
import AppShell from '@/components/layout/AppShell';
import DashboardPage from '@/pages/DashboardPage';
import UploadPage from '@/pages/UploadPage';
import AnalyzePage from '@/pages/AnalyzePage';
import ChatPage from '@/pages/ChatPage';

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <Routes>
          <Route element={<AppShell />}>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/upload" element={<UploadPage />} />
            <Route path="/analyze" element={<AnalyzePage />} />
            <Route path="/analyze/:fileId" element={<AnalyzePage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/chat/:fileId" element={<ChatPage />} />
          </Route>
        </Routes>
      </ToastProvider>
    </BrowserRouter>
  );
}
