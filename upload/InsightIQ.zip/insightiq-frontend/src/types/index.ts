/* ─── API Response Wrappers ─── */
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

export interface ApiError {
  success: false;
  error: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
}

/* ─── Health ─── */
export interface HealthData {
  status: 'healthy' | 'degraded';
  service: string;
  analyticsEngine: 'available' | 'unavailable' | 'missing_script';
  analyticsPythonPath?: string;
  ocr: string;
  openRouter: string;
  environment: string;
}

/* ─── File Upload ─── */
export interface UploadResult {
  fileId: string;
  fileName: string;
  originalName: string;
  fileSize: number;
  mimeType: string;
  uploadedAt: string;
}

/* ─── File Status ─── */
export type FileStatus =
  | 'uploaded'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'expired';

export interface FileStatusData {
  fileId: string;
  fileName: string;
  status: FileStatus;
  uploadedAt: string;
  completedAt?: string;
  error?: string;
}

/* ─── Analysis ─── */
export interface AnalysisData {
  fileId: string;
  fileName: string;
  fileType: 'TABULAR' | 'DOCUMENT' | 'UNKNOWN';
  format: string;
  category: string;
  rowCount?: number;
  columnCount?: number;
  columns?: ColumnInfo[];
  statistics?: Record<string, ColumnStats>;
  correlations?: CorrelationPair[];
  kpi?: KpiItem[];
  insights?: AiInsight[];
  aiAvailable: boolean;
  totalRows?: number;
  totalColumns?: number;
  missingCells?: number;
  missingPct?: number;
  duplicateRows?: number;
  memoryUsage?: string;
  processingTime?: number;
  textLength?: number;
  wordCount?: number;
}

export interface ColumnInfo {
  name: string;
  dataType: string;
  nonNullCount: number;
  nullCount: number;
  uniqueCount: number;
}

export interface ColumnStats {
  dataType: string;
  count: number;
  nullCount: number;
  unique: number;
  mean?: number;
  median?: number;
  std?: number;
  min?: number;
  max?: number;
  q1?: number;
  q3?: number;
  iqr?: number;
  skewness?: number;
  kurtosis?: number;
  topValues?: { value: string; count: number; pct: number }[];
}

export interface CorrelationPair {
  col1: string;
  col2: string;
  correlation: number;
}

export interface KpiItem {
  name: string;
  value: string;
  description: string;
}

export interface AiInsight {
  type: string;
  title: string;
  description: string;
  severity?: string;
  columns?: string[];
}

/* ─── Chat ─── */
export interface ChatRequest {
  question: string;
}

export interface ChatResponse {
  answer: string;
  sources?: string[];
}

/* ─── Processing History (client-side) ─── */
export interface ProcessingHistoryItem {
  fileId: string;
  fileName: string;
  fileType: string;
  status: FileStatus;
  uploadedAt: string;
  analyzedAt?: string;
  rowCount?: number;
  columnCount?: number;
}
