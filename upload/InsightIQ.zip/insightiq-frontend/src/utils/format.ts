export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function formatNumber(n: number | undefined | null): string {
  if (n == null || Number.isNaN(n)) return '—';
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n % 1 === 0 ? n.toString() : n.toFixed(2);
}

export function formatPercent(value: number | undefined | null, decimals = 1): string {
  if (value == null || Number.isNaN(value)) return '—';
  return `${value.toFixed(decimals)}%`;
}

export function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export function correlationColor(value: number): string {
  const abs = Math.abs(value);
  if (abs >= 0.7) return value > 0 ? 'text-emerald-400' : 'text-red-400';
  if (abs >= 0.4) return value > 0 ? 'text-emerald-300' : 'text-red-300';
  return 'text-surface-400';
}

export function correlationBg(value: number): string {
  const abs = Math.abs(value);
  if (abs >= 0.7) return value > 0 ? 'bg-emerald-500/20' : 'bg-red-500/20';
  if (abs >= 0.4) return value > 0 ? 'bg-emerald-500/10' : 'bg-red-500/10';
  return 'bg-surface-800';
}

export function severityColor(severity?: string): string {
  switch (severity) {
    case 'high': return 'badge-red';
    case 'medium': return 'badge-amber';
    case 'low': return 'badge-green';
    default: return 'badge-blue';
  }
}

export function truncate(str: string, maxLen: number): string {
  if (str.length <= maxLen) return str;
  return str.slice(0, maxLen - 3) + '...';
}

export const ACCEPTED_EXTENSIONS = [
  '.csv', '.tsv', '.txt', '.json', '.jsonl', '.ndjson',
  '.xlsx', '.xls', '.ods', '.parquet',
  '.pdf', '.docx', '.doc', '.pptx', '.ppt', '.odt', '.rtf',
  '.md', '.markdown', '.html', '.htm', '.xml', '.zip',
];

export const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
